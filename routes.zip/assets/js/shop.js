document.addEventListener('DOMContentLoaded', function() {
    // Handle sorting
    const orderSelect = document.getElementById('orderby');
    if (orderSelect) {
        orderSelect.addEventListener('change', function() {
            updateUrl('order', this.value);
        });
    }

    // Handle page size
    const pageSizeSelect = document.getElementById('pagesize');
    if (pageSizeSelect) {
        pageSizeSelect.addEventListener('change', function() {
            updateUrl('size', this.value);
        });
    }

    // Handle category filters
    const categoryCheckboxes = document.querySelectorAll('.chk-category');
    categoryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateCategoryFilter();
        });
    });

    // Handle brand filters
    const brandCheckboxes = document.querySelectorAll('.chk-brand');
    brandCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateBrandFilter();
        });
    });

    // Handle price range
    const priceRangeSlider = document.querySelector('.price-range-slider');
    if (priceRangeSlider) {
        priceRangeSlider.addEventListener('change', function() {
            const values = this.value.split(',');
            updateUrl('min', values[0]);
            updateUrl('max', values[1]);
        });
    }

    function updateCategoryFilter() {
        const selectedCategories = Array.from(document.querySelectorAll('.chk-category:checked'))
            .map(checkbox => checkbox.value);
        updateUrl('categories', selectedCategories.join(','));
    }

    function updateBrandFilter() {
        const selectedBrands = Array.from(document.querySelectorAll('.chk-brand:checked'))
            .map(checkbox => checkbox.value);
        updateUrl('brands', selectedBrands.join(','));
    }

    function updateUrl(param, value) {
        const url = new URL(window.location.href);
        if (value) {
            url.searchParams.set(param, value);
        } else {
            url.searchParams.delete(param);
        }
        window.location.href = url.toString();
    }
}); 