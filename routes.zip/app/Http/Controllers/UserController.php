<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use Carbon\Carbon;
use App\Models\OrderItem;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index()
    {
        return view('user.index');
    }

    public function orders()
    {
        $orders = Order::where('user_id',Auth::user()->id)->orderBy('created_at','DESC')->paginate(10);
        return view('user.orders',compact('orders'));
    }

    public function order_details($order_id)
    {
        $order =Order::where('user_id',Auth::user()->id)->where('id',$order_id)->first();

        if($order)
        {
            $orderItems=OrderItem::where('order_id',$order->id)->orderBy('id')->paginate(12);
            $transaction=Transaction::where('order_id',$order->id)->first();
            return view('user.order-details',compact('order','orderItems','transaction'));
        }
        else
        {
            return redirect()->route('login');
        }
    }
    public function order_cancel(Request $request)
    {
        // Validate the request
        $request->validate([
            'order_id' => 'required|exists:orders,id'
        ]);

        // Get the order
        $order = Order::where('id', $request->order_id)
            ->where('user_id', Auth::id())
            ->first();

        // Check if order exists and belongs to the user
        if (!$order) {
            return back()->with('error', 'Order not found or you do not have permission to cancel this order.');
        }

        // Check if order can be canceled
        if ($order->status === 'delivered') {
            return back()->with('error', 'Cannot cancel an order that has already been delivered.');
        }

        if ($order->status === 'canceled') {
            return back()->with('error', 'This order has already been canceled.');
        }

        // Update order status
        $order->status = 'canceled';
        $order->canceled_date = Carbon::now();
        $order->save();

        return back()->with('success', 'Order has been canceled successfully!');
    }
}
