<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rating;
use Illuminate\Support\Facades\Auth;

class RatingController extends Controller
{
    /**
     * Store or update a rating.
     */
  public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'stars' => 'required|integer|min:1|max:5',
            'product_id' => 'required|string|max:255',
        ]);

        $rating = Rating::create([
            'name' => $request->name,
            'email' => $request->email,
            'stars' => $request->stars,
            'product_id' => $request->product_id,
            'user_id' => Auth::id(),
            'status' => 1,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Thank you for your rating!',
            'rating' => $rating
        ]);
    }
    public function getProductRatings($productId)
{
    $ratings = Rating::with('user')->where('status',1)->where('product_id', $productId)->orderBy('id', 'DESC')->get();
    $ratingsSum = Rating::where('status',1)->where('product_id', $productId)->sum('stars',1);
    $ratingsCount = Rating::where('status',1)->where('product_id', $productId)->count();
    if($ratingsCount >0){
        $averageRating = round($ratingsSum / $ratingsCount, 2);
        $avgstarRating=round($ratingsSum / $ratingsCount);
    }else{

        $averageRating = 0;
        $avgstarRating=0;

    }
    $averageRating = $ratingsCount > 0 ? round($ratingsSum / $ratingsCount, 1) : 0;
    return response()->json([
        'ratings' => $ratings,
        'averageRating' => $averageRating,
        'ratingsCount' => $ratingsCount,
        'avgstarRating' => $avgstarRating,
    ]);
}
}


