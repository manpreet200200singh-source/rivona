<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\About2;
use Carbon\Carbon;


class About2Controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('admin.about2');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $about =About2::all();
        return view('admin.about_table',compact('about'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

            $request->validate([
            'story'=>'required',
            'mission'=>'required',
            'vision'=>'required',
            'company'=>'required',
            'pic'=>'required',
            ]);
            $about=new About2();
            $about->story=$request->story;
            $about->mission=$request->mission;
            $about->vision=$request->vision;
            $about->company=$request->company;
            $pic=$request->file('pic');
            $file_extention=$request->file('pic')->extension();
            $file_name=Carbon::now()->timestamp.'.'.$file_extention;
            $pic->move(public_path('uploads/about'), $file_name);
            $about->pic=$file_name;
            $about->save();
            return redirect()->route('about_form')->with('status','About has been added successfully!');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $about = About2::find($id);
        return view('admin.edit_about', compact('about'));
    }



public function update(Request $request, string $id)
    {
        // Validate the incoming request data
        $request->validate([
            'story' => 'required',
            'mission' => 'required',
            'vision' => 'required',
            'company' => 'required',
            'pic' => 'required',
        ]);
        // Find the About2 record by ID
        $about = About2::findOrFail($id);
        // Update the fields with the validated data
        $about->story = $request->story;
        $about->mission = $request->mission;
        $about->vision = $request->vision;
        $about->company = $request->company;
        // Handle the optional 'pic' field
        if ($request->hasFile('pic')) {
            // Get the file extension
            $file_extension = $request->file('pic')->getClientOriginalExtension();
            // Create a unique file name using time()
            $file_name = time() . '.' . $file_extension;
            // Move the uploaded file to the specified directory
            $request->file('pic')->move(public_path('uploads/about'), $file_name);
            // Save the file name to the database
            $about->pic = $file_name;
        }
        // Save the updated record to the database
        $about->save();
        // Redirect with a success message
        return redirect('/about/table')->with('status', 'About has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $about = About2::find($id);

        if ($about) {
            @unlink(public_path('uploads/about/' . $about->pic)); // deletes the image (safely)
            $about->delete(); // deletes the database record
        }

        return redirect()->route('about_table')->with('status', 'About has been deleted successfully!');

    }
}

