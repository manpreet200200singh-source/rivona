<?php

namespace App\Http\Controllers;

use App\Models\quiry;
use Illuminate\Http\Request;
use Carbon\Carbon;

class QuiryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $quiries=quiry::all();
         $quiries = quiry::paginate(10);
        return view('quirytable',compact('quiries'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('quiry');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)

    {
        $request->validate([
            'fullname' => 'string|max:255',
            'email' => 'email|max:255',
            'number' => 'string|max:15',
            'ordernumber' => 'string|max:50',
            'inquiry' => 'string',
            'subject' => 'string|max:255',
            'message' => 'string',
            'file' => 'file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);
            $inquiry=new quiry();
            $inquiry->fullname=$request->fullname;
            $inquiry->email=$request->email;
            $inquiry->number=$request->number;
            $inquiry->ordernumber=$request->ordernumber;
            $inquiry->inquiry=$request->inquiry;
            $inquiry->subject=$request->subject;
            $inquiry->message=$request->message;
            $file=$request->file('file');
            $file_extention=$request->file('file')->extension();
            $file_name=Carbon::now()->timestamp.'.'.$file_extention;
            $file->move(public_path('uploads/inquiry'), $file_name);
            $inquiry->file=$file_name;
            $inquiry->save();
            return redirect()->route('query')->with('status','Inquiry has been added successfully!');
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
         $quiry = quiry::find($id);

        if ($quiry) {
            @unlink(public_path('uploads/inquiry/' . $quiry->file)); // deletes the image (safely)
            $quiry->delete(); // deletes the database record
        }

        return redirect('/inquirytable')->with('status', 'Slider has been deleted successfully!');

    }
}
