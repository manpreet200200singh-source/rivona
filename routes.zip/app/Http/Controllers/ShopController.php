<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Brand;
use App\Models\Category;
use App\Models\black;
USE App\Models\Rating;

class ShopController extends Controller
{
    public function index(Request $request){
        $size = $request->query('size') ? (int)$request->query('size') : 12;
        $order = $request->query('order') ? (int)$request->query('order') : -1;
        $f_brands = $request->query('brands') ?? '';
        $f_categories = $request->query('categories') ?? '';
        $min_price = $request->query('min') ? (float)$request->query('min') : 1;
        $max_price = $request->query('max') ? (float)$request->query('max') : 500;
        // Get brands and categories for filters
        $brands = Brand::orderBy('name', 'ASC')->get();
        $categories = Category::orderBy('name', 'ASC')->get();
        $black=black::all();

        // Start building the query
        $query = Product::query();

        // Apply brand filter
        if (!empty($f_brands)) {
            $brandIds = explode(',', $f_brands);
            $query->whereIn('brand_id', $brandIds);
        }

        // Apply category filter
        if (!empty($f_categories)) {
            $categoryIds = explode(',', $f_categories);
            $query->whereIn('category_id', $categoryIds);
        }

        // Apply price range filter
        $query->where(function($q) use ($min_price, $max_price) {
            $q->whereBetween('regular_price', [$min_price, $max_price])
              ->orWhereBetween('sale_price', [$min_price, $max_price]);
        });

        // Apply sorting
        if ($order == 1) {
            $query->orderBy('created_at', 'DESC');
        } elseif ($order == 2) {
            $query->orderBy('created_at', 'ASC');
        } elseif ($order == 3) {
            $query->orderBy('sale_price', 'ASC')->orderBy('regular_price', 'ASC');
        } elseif ($order == 4) {
            $query->orderBy('sale_price', 'DESC')->orderBy('regular_price', 'DESC');
        } else {
            $query->orderBy('id', 'DESC');
        }

        // Get the results
        $products = $query->paginate($size);
         $rating=Rating::all();

        return view('shop', compact(
            'products',
            'size',
            'order',
            'categories',
            'brands',
            'f_brands',
            'f_categories',
            'min_price',
            'max_price','black'
,'rating'
        ));
    }
    public function  product_details($product_slug){
        $rating=Rating::all();
        $product=Product::where('slug',$product_slug)->first();
       $rproducts=Product::where('slug','<>',$product_slug)->take(8)->get();
        return view('details',compact('product','rproducts','rating'));
    }

}

