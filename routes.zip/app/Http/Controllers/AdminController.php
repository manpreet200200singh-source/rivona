<?php

namespace App\Http\Controllers;


use Carbon\Carbon;
use App\Models\Brand;
use App\Models\Order;
use App\Models\Slide;
use App\Models\Coupon;
use App\Models\Rating;
use App\Models\Contact;
use App\Models\Product;
use App\Models\Category;
use Milon\Barcode\DNS1D;
use App\Models\OrderItem;
use App\Models\Transaction;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Intervention\Image\Laravel\Facades\Image;
use Picqer\Barcode\BarcodeGeneratorPNG; // Import the BarcodeGeneratorPNG class




class AdminController extends Controller
{

    public function index()
    {
        $orders = Order::orderBy('created_at', 'DESC')->get()->take(10);
        $dashboardDatas = order::selectRaw('
            SUM(total) AS TotalAmount,
            SUM(CASE WHEN status = "ordered" THEN total ELSE 0 END) AS TotalOrderedAmount,
            SUM(CASE WHEN status = "delivered" THEN total ELSE 0 END) AS TotalDeliveredAmount,
            SUM(CASE WHEN status = "canceled" THEN total ELSE 0 END) AS TotalCanceledAmount,
            COUNT(*) AS Total,
            SUM(CASE WHEN status = "ordered" THEN 1 ELSE 0 END) AS TotalOrdered,
            SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) AS TotalDelivered,
            SUM(CASE WHEN status = "canceled" THEN 1 ELSE 0 END) AS TotalCanceled
            ')
            ->first();

        $monthlyDates = DB::select("SELECT M.id AS MonthNo, M.name AS MonthName,
                IFNULL(D.TotalAmount,0) AS TotalAmount,
                IFNULL(D.TotalOrderedAmount,0) AS TotalOrderedAmount,
                IFNULL(D.TotalDeliveredAmount,0) AS TotalDeliveredAmount,
                IFNULL(D.TotalCanceledAmount,0) AS TotalCanceledAmount
                FROM month_names M
                LEFT JOIN (
                    SELECT
                        MONTH(created_at) AS MonthNo,
                        DATE_FORMAT(created_at,'%b') AS MonthName,
                        SUM(total) AS TotalAmount,
                        SUM(CASE WHEN status='ordered' THEN total ELSE 0 END) AS TotalOrderedAmount,
                        SUM(CASE WHEN status='delivered' THEN total ELSE 0 END) AS TotalDeliveredAmount,
                        SUM(CASE WHEN status='canceled' THEN total ELSE 0 END) AS TotalCanceledAmount
                    FROM orders
                    WHERE YEAR(created_at) = YEAR(NOW())
                    GROUP BY YEAR(created_at), MONTH(created_at), DATE_FORMAT(created_at,'%b')
                    ORDER BY MONTH(created_at)
                ) D ON D.MonthNo = M.id");
        $AmountM = implode(',', collect($monthlyDates)->pluck('TotalAmount')->toArray());
        $OrderedAmountM = implode(',', collect($monthlyDates)->pluck('TotalOrderedAmount')->toArray());
        $DeliveredAmountM = implode(',', collect($monthlyDates)->pluck('TotalDeliveredAmount')->toArray());
        $CanceledAmountM = implode(',', collect($monthlyDates)->pluck('TotalCanceledAmount')->toArray());


        $TotalAmount = collect($monthlyDates)->sum('TotalAmount');
        $TotalOrderedAmount = collect($monthlyDates)->sum('TotalOrderedAmount');
        $TotalDeliveredAmount = collect($monthlyDates)->sum('TotalDeliveredAmount');
        $TotalCanceledAmount = collect($monthlyDates)->sum('TotalCanceledAmount');

        $TotalAmount = collect($monthlyDates)->sum('TotalAmount');
        return view('admin.index', compact('orders', 'dashboardDatas', 'AmountM', 'OrderedAmountM', 'DeliveredAmountM', 'CanceledAmountM', 'TotalOrderedAmount', 'TotalAmount', 'TotalDeliveredAmount', 'TotalCanceledAmount'));
    }

    public function brands()
    {
        $brands = Brand::orderBy('id', 'DESC')->paginate(10);
        return view('admin.brands', compact('brands'));
    }

    public function add_brand()
    {
        return view('admin.brand-add');
    }

    public function brand_store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'slug' => 'required',
            'image' => 'required',
        ]);
        $brand = new Brand();
        $brand->name = $request->name;
        $brand->slug = Str::slug($request->name);
        $image = $request->file('image');
        $file_extention = $request->file('image')->extension();
        $file_name = Carbon::now()->timestamp . '.' . $file_extention;
        $this->GenerateBrandThumbailsImage($image, $file_name);
        $brand->image = $file_name;
        $brand->save();
        return redirect()->route('admin.brands')->with('status', 'Brand has been added successfully!');
    }

    public function brand_edit($id)
    {
        $brand = Brand::find($id);
        return view('admin.brand-edit', compact('brand'));
    }

    public function brand_update(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'slug' => 'required',
            'image' => 'required',
        ]);
        $brand = Brand::find($request->id);
        $brand->name = $request->name;
        $brand->slug = Str::slug($request->name);
        if ($request->hasFile('image')) {
            if (File::exists(public_path('uploads/Brands') . '/' . $brand->image)); {
                File::delete(public_path('uploads/Brands') . '/' . $brand->image);
            }
            $image = $request->file('image');
            $file_extention = $request->file('image')->extension();
            $file_name = Carbon::now()->timestamp . '.' . $file_extention;
            $this->GenerateBrandThumbailsImage($image, $file_name);
            $brand->image = $file_name;
        }
        $brand->save();
        return redirect()->route('admin.brands')->with('status', 'Brand has been updated successfully!');
    }

    public function GenerateBrandThumbailsImage($image, $imageName)
    {
        $destinationPath = public_path('uploads/Brands');
        $img = Image::read($image->path());
        $img->cover(124, 124, "top");
        $img->resize(
            124,
            124,
            function ($constraint) {
                $constraint->aspectRatio();
            }
        )->save($destinationPath . '/' . $imageName);
    }

    public function brand_delete($id)
    {
        $brand = Brand::find($id);
        if (File::exists(public_path('uploads/Brands') . '/' . $brand->image)) {
            File::delete(public_path('uploads/Brands') . '/' . $brand->image);
        }
        $brand->delete();
        return redirect()->route('admin.brands')->with('status', 'Brand has been deleted successfully!');
    }
    // Brand Controller end

    // Category Controller

    public function categories()
    {
        $categories = Category::orderBy('id', 'DESC')->paginate(10);
        return view('admin.categories', compact('categories'));
    }
    public function categories_add()
    {
        return view('admin.categories-add');
    }

    public function categories_store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'slug' => '',
            'image' => 'required',
        ]);
        $categories = new Category();
        $categories->name = $request->name;
        $categories->slug = Str::slug($request->name);
        $image = $request->file('image');
        $file_extention = $request->file('image')->extension();
        $file_name = Carbon::now()->timestamp . '.' . $file_extention;
        $this->GeneratecategoriesThumbailsImage($image, $file_name);
        $categories->image = $file_name;
        $categories->save();
        return redirect()->route('admin.categories')->with('status', 'Category has been added successfully!');
    }

    public function GeneratecategoriesThumbailsImage($image, $imageName)
    {
        $destinationPath = public_path('uploads/Categories');
        $img = Image::read($image->path());
        $img->cover(124, 124, "top");
        $img->resize(124, 124, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $imageName);
    }

    public function categories_edit($id)
    {
        $categories = Category::find($id);
        return view('admin.categories-edit', compact('categories'));
    }

    public function categories_update(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'slug' => 'required',
            'image' => 'required',
        ]);
        $categories = Category::find($request->id);
        $categories->name = $request->name;
        $categories->slug = Str::slug($request->name);
        if ($request->hasFile('image')) {
            if (File::exists(public_path('uploads/Categories') . '/' . $categories->image)); {
                File::delete(public_path('uploads/Categories') . '/' . $categories->image);
            }
            $image = $request->file('image');
            $file_extention = $request->file('image')->extension();
            $file_name = Carbon::now()->timestamp . '.' . $file_extention;
            $this->GeneratecategoriesThumbailsImage($image, $file_name);
            $categories->image = $file_name;
        }
        $categories->save();
        return redirect()->route('admin.categories')->with('status', 'Category has been updated successfully!');
    }

    public function categories_delete($id)
    {
        $categories = Category::find($id);
        if (File::exists(public_path('uploads/Categories') . '/' . $categories->image)) {
            File::delete(public_path('uploads/Categories_delete') . '/' . $categories->image);
        }
        $categories->delete();
        return redirect()->route('admin.categories')->with('status', 'Category has been deleted successfully!');
    }

    // Category Controller end
    // Product Controller

    public function products()
    {
        $products = Product::orderBy('created_at', 'DESC')->paginate(10);
        return view('admin.products', compact('products'));;
        //eh hi aa ? jida image krvayi di aa
    }

    public function product_add()
    {
        $category = Category::select('id', 'name')->orderBy('name')->get();
        $brands = Brand::select('id', 'name')->orderBy('name')->get();
        return view('admin.product-add', compact('category', 'brands'));
    }
    // copy paste start

    public function products_store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'released_date' => 'nullable|date',
            'region_code' => 'nullable|string|max:100',
            'language' => 'nullable|string|max:100',
            'duration' => 'nullable|string|max:100',
            'slug' => 'required|unique:products,slug',
            'short_description' => 'required',
            'description' => 'required',
            'regular_price' => 'required',
            'sale_price' => 'required',
            'SKU' => 'required',

            'featured' => 'required',
            'quantity' => 'required',
            'image' => 'required',
            'category_id' => 'required',
            'brand_id' => 'required',
            'images' => 'required',
            'images.*' => 'image|mimes:jpg,png,jpeg|max:2048',
            'productcode' => 'required|string|max:100',

        ]);

        $product = new Product();
        $product->name = $request->name;
        $product->released_date = $request->released_date;
        $product->region_code = $request->region_code;
        $product->language = $request->language;
        $product->duration = $request->duration;
        $product->slug = Str::slug($request->name);
        $product->short_description = $request->short_description;
        $product->description = $request->description;
        $product->regular_price = $request->regular_price;
        $product->sale_price = $request->sale_price;
        $product->SKU = $request->SKU;


        //automatically stock status set
        if($request->quantity > 0){
            $product->stock_status = 'instock';
        }else{
            $product->stock_status = 'outofstock';
        }

        $product->featured = $request->featured;
        $product->quantity = $request->quantity;
        $product->category_id = $request->category_id;
        $product->brand_id = $request->brand_id;
        $product->productcode = $request->productcode;


        //Generate barcode from product code start
        $generator = new BarcodeGeneratorPNG();
        $barcodeImageName = time() . '_barcode.png';
        $barcodeImagePath = public_path('barcodes/' . $barcodeImageName);
        file_put_contents($barcodeImagePath, $generator->getBarcode($request->productcode, $generator::TYPE_CODE_128));
        $product->barcode = $request->productcode;
        // Store the product code as the barcode end


        $current_timestamp = Carbon::now()->timestamp;
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $imageName = $current_timestamp . '.' . $image->extension();
            $this->GenerateProductThumbailImage($image, $imageName);
            $product->image = $imageName;
        }
        $gallery_arr = array();
        $gallery_images = "";
        $counter = 1;

        if ($request->hasfile('images')) {
            $allowedfileExtion = ['jpg', 'png', 'jpeg'];
            $files = $request->file('images');
            foreach ($files as $file) {
                $gextension = $file->getClientOriginalExtension();
                $gcheck = in_array($gextension, $allowedfileExtion);
                if ($gcheck) {
                    $gfileName = $current_timestamp . "-" . $counter . "." . $gextension;
                    $this->GenerateProductThumbailImage($file, $gfileName);
                    $gallery_arr[] = $gfileName;
                    $counter = $counter + 1;
                }
            }
            $gallery_images = implode(',', $gallery_arr);
        }
        $product->images = $gallery_images;
        //addition
        $product->barcode_img = 'barcodes/' . $barcodeImageName;
        //end addition
        $product->save();
        return redirect()->route('admin.products')->with('status', 'Product has been added Successfully');
    }

    // copy paste end



    public function GenerateProductThumbnailImage($image, $imageName)
    {
        // Define the path where the image will be stored
        $path = public_path('images/products/' . $imageName);

        // Create an instance of the image and resize it
        $img = Image::read($image->getRealPath());

        // Resize the image to a thumbnail size (e.g., 300x300)
        $img->resize(300, 300, function ($constraint) {
            $constraint->aspectRatio();
            $constraint->upsize();
        });

        // Save the image to the specified path try karyo minu error mwssage chahide

        $barcode_img = $img->save($path);
    }

    public function product_edit($id)
    {
        $product = Product::find($id);
        $category = Category::select('id', 'name')->orderBy('name')->get();
        $brands = Brand::select('id', 'name')->orderBy('name')->get();
        return view('admin.product-edit', compact('product', 'category', 'brands'));
    }

    public function product_update(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'released_date' => 'nullable|date',
            'region_code' => 'nullable|string|max:1000',
            'language' => 'nullable|string|max:1000',
            'duration' => 'nullable|string|max:1000',
            'slug' => 'required|unique:products,slug,' . $request->id,
            'short_description' => 'required',
            'description' => 'required',
            'regular_price' => 'required',
            'sale_price' => 'required',
            'SKU' => 'required',
            'featured' => 'required',
            'quantity' => 'required',
            'image' => 'mimes:png,jpg,jpeg|max:2048',
            'category_id' => 'required',
            'brand_id' => 'required',
            'images.*' => 'image|mimes:jpg,png,jpeg|max:2048',
            'productcode' => 'required|string|max:100',
        ]);
        $product = Product::find($request->id);
        $product->name = $request->name;
        $product->released_date = $request->released_date;
        $product->region_code = $request->region_code;
        $product->language = $request->language;
        $product->duration = $request->duration;
        $product->slug = Str::slug($request->name);
        $product->short_description = $request->short_description;
        $product->description = $request->description;
        $product->regular_price = $request->regular_price;
        $product->sale_price = $request->sale_price;
        $product->SKU = $request->SKU;

        if($product->quantity > 0) {
            if ( $request->quantity > 0 ) {
                $product->stock_status = 'instock';
            } else {
                $product->stock_status = 'outofstock';
            }
        } else {
            $product->stock_status = 'outofstock';
        }
        // $product->stock_status = $request->stock_status;
        $product->featured = $request->featured;
        $product->quantity = $request->quantity;
        $product->category_id = $request->category_id;
        $product->brand_id = $request->brand_id;
        $product->productcode = $request->productcode;

        // Generate barcode from product code
        $generator = new BarcodeGeneratorPNG();
        $barcodeImageName = time() . '_barcode.png';
        $barcodeImagePath = public_path('barcodes/' . $barcodeImageName);
        file_put_contents($barcodeImagePath, $generator->getBarcode($request->productcode, $generator::TYPE_CODE_128));
        $product->barcode = $request->productcode;
        $product->barcode_img = 'barcodes/' . $barcodeImageName;

        $current_timestamp = Carbon::now()->timestamp;
        if ($request->hasFile('image')) {
            if (File::exists(public_path('uploads/products') . '/' . $product->image)) {
                File::delete(public_path('uploads/products') . '/' . $product->image);
                File::delete(public_path('uploads/products/thumbnails') . '/' . $product->image);
            }
            $image = $request->file('image');
            $imageName = $current_timestamp . '.' . $image->extension();
            $this->GenerateProductThumbailImage($image, $imageName);
            $product->image = $imageName;
        }

        $gallery_arr = [];
        $gallery_images = "";
        $counter = 1;

        if ($request->hasFile('images')) {
            $allowedfileExtion = ['jpg', 'png', 'jpeg'];
            $files = $request->file('images');
            foreach ($files as $file) {
                $gextension = $file->getClientOriginalExtension();
                $gcheck = in_array($gextension, $allowedfileExtion);
                if ($gcheck) {
                    $gfileName = $current_timestamp . "-" . $counter . "." . $gextension;
                    $this->GenerateProductThumbailImage($file, $gfileName);
                    $gallery_arr[] = $gfileName;
                    $counter = $counter + 1;
                }
            }
            $gallery_images = implode(',', $gallery_arr);
            if ($product->images) {
                $gallery_images = $product->images . "," . $gallery_images;
            }
            $product->images = $gallery_images;
        }

        $product->save();
        return redirect()->route('admin.products')->with('status', 'Product has been updated Successfully');
    }
    //////////////////////////////////
    public function getQuantity($id)
    {
        $product = Product::findOrFail($id);
        return  $product->quantity;
    }
    ///////////////////////////////////
    public function GenerateProductThumbailImage($image, $imageName)
    {
        $destinationPathThumbnail = public_path('uploads/products/thumbnails');
        $destinationPath = public_path('uploads/products');
        $img = Image::read($image->path());

        $img->cover(540, 689, "top");
        $img->resize(540, 689, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $imageName);

        $img->resize(104, 104, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPathThumbnail . '/' . $imageName);
    }
    public function product_delete($id)
    {
        $product = Product::find($id);
        if (File::exists(public_path('uploads/products') . '/' . $product->image)) {
            File::delete(public_path('uploads/products') . '/' . $product->image);
            File::delete(public_path('uploads/products/thumbnails') . '/' . $product->image);
        }
        $images = explode(',', $product->images);
        foreach ($images as $image) {
            if (File::exists(public_path('uploads/products') . '/' . $image)) {
                File::delete(public_path('uploads/products') . '/' . $image);
                File::delete(public_path('uploads/products/thumbnails') . '/' . $image);
            }
        }
        $product->delete();
        return redirect()->route('admin.products')->with('status', 'Product has been deleted successfully!');
    }

    // Product Controller end

    public function Coupons()
    {
        $coupons = Coupon::orderBy('expiry_date', 'DESC')->paginate(12);
        return view('admin.coupons', compact('coupons'));
    }
    public function coupon_add()
    {
        return view('admin.coupon-add');
    }
    public function coupon_store(Request $request)
    {
        $request->validate([
            'code' => 'required',
            'type' => 'required',
            'value' => 'required|numeric',
            'cart_value' => 'required|numeric',
            'expiry_date' => 'required|date'

        ]);
        $coupon = new Coupon();
        $coupon->code = $request->code;
        $coupon->type = $request->type;
        $coupon->value = $request->value;
        $coupon->cart_value = $request->cart_value;
        $coupon->expiry_date = $request->expiry_date;
        $coupon->save();
        return redirect()->route('admin.coupons')->with('status', 'Coupon has been added successfully');
    }







    public function coupon_edit($id)
    {
        $coupon = Coupon::find($id);
        return view('admin.coupon-edit', compact('coupon'));
    }
    public function coupon_update(Request $request)
    {
        $request->validate([
            'code' => 'required',
            'type' => 'required',
            'value' => 'required|numeric',
            'cart_value' => 'required|numeric',
            'expiry_date' => 'required|date'
        ]);

        $coupon = Coupon::find($request->id);
        $coupon->code = $request->code;
        $coupon->type = $request->type;
        $coupon->value = $request->value;
        $coupon->cart_value = $request->cart_value;
        $coupon->expiry_date = $request->expiry_date;
        $coupon->save();
        return redirect()->route('admin.coupons')->with('status', "Coupon has been updated successfully !");
    }
    public function coupon_delete($id)
    {
        $coupon = Coupon::find($id);
        $coupon->delete();
        return redirect()->route('admin.coupons')->with('status', 'Coupon has been deleted successfully !');
    }

    public function orders()
    {
        $orders = Order::orderBy('created_at', 'DESC')->paginate(12);
        return view('admin.orders', compact('orders'));
    }

    public function order_details($order_id)
    {
        $order = Order::find($order_id);
        $orderItems = OrderItem::where('order_id', $order_id)->orderBy('id')->paginate(12);
        $transaction = Transaction::where('order_id', $order_id)->first();
        return view('admin.order-details', compact('order', 'orderItems', 'transaction'));
    }

    public function update_order_status(Request $request)
    {
        $order = Order::find($request->order_id);
        $order->status = $request->order_status;
        if ($request->order_status == 'delivered') {
            $order->delivered_date = Carbon::now();
        } elseif ($request->order_status == 'canceled') {
            $order->canceled_date = Carbon::now();
        }
        $order->save();
        if ($request->order_status == 'delivered') {
            $transaction = Transaction::where('order_id', $request->order_id)->first();
            $transaction->status = 'approved';
            $transaction->save();
        }
        return back()->with("status", "Status changed successfully!");
    }

    public function slides()
    {
        $slides = Slide::orderBy('id', 'DESC')->paginate(12);
        return view('admin.slides', compact('slides'));
    }
    public function slide_add()
    {
        return view('admin.slide-add');
    }
    public function slide_store(Request $request)
    {
        $request->validate([
            'tagline' => 'required',
            'title' => 'required',
            'subtitle' => 'required',
            'link' => 'required',
            'status' => 'required',
            'image' => 'required|mimes:png,jpg,jpeg|max:2048'
        ]);
        $slide = new Slide();
        $slide->tagline = $request->tagline;
        $slide->title = $request->title;
        $slide->subtitle = $request->subtitle;
        $slide->link = $request->link;
        $slide->status = $request->status;

        $image = $request->file('image');
        $file_extention = $request->file('image')->extension();
        $file_name = Carbon::now()->timestamp . '.' . $file_extention;
        $this->GenerateSlideThumbailsImage($image, $file_name);
        $slide->image = $file_name;
        $slide->save();
        return redirect()->route('admin.slides')->with("status", "Slide added successfully");
    }
    public function GenerateSlideThumbailsImage($image, $imageName)
    {
        $destinationPath = public_path('uploads/slides');
        $img = Image::read($image->path());
        $img->cover(400, 690, "top");
        $img->resize(400, 690, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath . '/' . $imageName);
    }
    public function slide_edit($id)
    {
        $slide = Slide::find($id);
        return view('admin.slide-edit', compact('slide'));
    }

    public function slide_update(Request $request)
    {

        $request->validate([
            'tagline' => 'required',
            'title' => 'required',
            'subtitle' => 'required',
            'link' => 'required',
            'status' => 'required',
            'image' => 'mimes:png,jpg,jpeg|max:2048'
        ]);
        $slide = Slide::find($request->id);
        $slide->tagline = $request->tagline;
        $slide->title = $request->title;
        $slide->subtitle = $request->subtitle;
        $slide->link = $request->link;
        $slide->status = $request->status;

        if ($request->hasfile('image')) {
            if (File::exists(public_path('uploads/slides') . '/' . $slide->image)) {
                File::delete(public_path('uploads/slides') . '/' . $slide->image);
            }
            $image = $request->file('image');
            $file_extention = $request->file('image')->extension();
            $file_name = Carbon::now()->timestamp . '.' . $file_extention;
            $this->GenerateSlideThumbailsImage($image, $file_name);
            $slide->image = $file_name;
        }
        $slide->save();
        return redirect()->route('admin.slides')->with("status", "Slide updated successfully");
    }

    public function slide_delete($id)
    {
        $slide = Slide::find($id);
        if (File::exists(public_path('uploads/slides') . '/' . $slide->image)) {
            File::delete(public_path('uploads/slides') . '/' . $slide->image);
        }
        $slide->delete();
        return redirect()->route('admin.slides')->with('status', 'slide has been deleted successfully!');
    }

    public function contacts()
    {
        $contacts = Contact::orderBy('created_at', 'DESC')->paginate(10);
        return view('admin.contacts', compact('contacts'));
    }
    public function contact_delete($id)
    {
        $contact = Contact::find($id);
        $contact->delete();
        return redirect()->route('admin.contacts')->with("status", "Contact deleted successfully");
    }
    public function search(Request $request)
    {
        $query = $request->input('query');
        $results = Product::where('name', 'LIKE', "%{$query}%")->get()->take(8);
        return response()->json($results);
    }
        public function getProductRatings($productId)
{
    $ratings = Rating::where('product_id', $productId)->get();
    $ratingsSum = Rating::where('product_id', $productId)->sum('stars');
    $ratingsCount = Rating::where('product_id', $productId)->count();
    if($ratingsCount > 0){
        $averageRating = round($ratingsSum / $ratingsCount, 2);
        $avgstarRating = round($ratingsSum / $ratingsCount);
    }else{
        $averageRating = 0;
        $avgstarRating = 0;
    }
    return view('details', compact('ratings','avgstarRating'));
}
}
