<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\About2;

class AboutController extends Controller
{
    public function index()
    {
        $about=About2::get()->take(1);
        return view('about',compact('about'));
    }
}

