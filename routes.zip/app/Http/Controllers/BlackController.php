<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\black;
use Carbon\Carbon;

class BlackController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $black=black::all();
        return view('admin.blackslider.index',compact('black'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.blackslider.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

            $request->validate([
            'title'=>'required',
            'description'=>'required',
            'image'=>'required',
            ]);
            $slider=new black();
            $slider->title=$request->title;
            $slider->description=$request->description;

            $image=$request->file('image');
            $file_extention=$request->file('image')->extension();
            $file_name=Carbon::now()->timestamp.'.'.$file_extention;
            $image->move(public_path('uploads/black'), $file_name);
            $slider->image=$file_name;
            $slider->save();
            return redirect()->route('blackslider')->with('status','Data has been added successfully!');
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
  {
         $black = black::find($id);
        return view('admin.blackslider.edit', compact('black'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
             'title'=>'required',
            'description'=>'required',
            'image'=>'required',
        ]);
        $black = black::findOrFail($id);
        $black->title = $request->title;
        $black->description = $request->description;
        if ($request->hasFile('image')) {
            $file_extension = $request->file('image')->getClientOriginalExtension();
            $file_name = time() . '.' . $file_extension;
            $request->file('image')->move(public_path('uploads/black'), $file_name);
            $black->image = $file_name;
        }
        $black->save();
        return redirect('/blackslidershow')->with('status', 'Data has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
         $black = black::find($id);

        if ($black) {
            @unlink(public_path('uploads/black/' . $black->image)); // deletes the image (safely)
            $black->delete(); // deletes the database record
        }

        return redirect('/blackslidershow')->with('status', 'Slider has been deleted successfully!');
    }
}
