<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\PaytmService;
use App\Models\Order;
use App\Models\Transaction;
use Illuminate\Support\Facades\Log;

class PaytmController extends Controller
{
    protected $paytmService;

    public function __construct(PaytmService $paytmService)
    {
        $this->paytmService = $paytmService;
    }

    public function initiatePayment($order_id)
    {
        try {
            $order = Order::findOrFail($order_id);
            return $this->paytmService->initiatePayment($order);
        } catch (\Exception $e) {
            Log::error('Paytm Payment Initiation Error: ' . $e->getMessage());
            return redirect()->route('cart.index')->with('error', 'Failed to initiate payment. Please try again.');
        }
    }

    public function callback(Request $request)
    {
        try {
            $order_id = $request->get('ORDERID');
            $order = Order::findOrFail($order_id);
            
            $isValidPayment = $this->paytmService->verifyPayment($request);
            
            if ($isValidPayment) {
                // Update order status
                $order->status = 'ordered';
                $order->save();

                // Create transaction record
                $transaction = new Transaction();
                $transaction->user_id = $order->user_id;
                $transaction->order_id = $order->id;
                $transaction->mode = 'paytm';
                $transaction->status = 'approved';
                $transaction->save();

                // Clear cart and session data
                \Cart::instance('cart')->destroy();
                session()->forget(['checkout', 'coupon', 'discounts']);

                return redirect()->route('cart.order.confirmation')->with('success', 'Payment successful!');
            } else {
                // Update order status to canceled
                $order->status = 'canceled';
                $order->save();

                // Create failed transaction record
                $transaction = new Transaction();
                $transaction->user_id = $order->user_id;
                $transaction->order_id = $order->id;
                $transaction->mode = 'paytm';
                $transaction->status = 'declined';
                $transaction->save();

                return redirect()->route('cart.index')->with('error', 'Payment failed. Please try again.');
            }
        } catch (\Exception $e) {
            Log::error('Paytm Payment Callback Error: ' . $e->getMessage());
            return redirect()->route('cart.index')->with('error', 'Payment verification failed. Please contact support.');
        }
    }
} 