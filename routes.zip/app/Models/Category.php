<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
USE Illuminate\Database\Eloquent\Factories\HasFactory;

class Category extends Model
{
    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
