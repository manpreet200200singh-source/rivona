<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class About2 extends Model
{
    protected $fillable=['pic','story','mission','vision','company'];
}
