<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class quiry extends Model
{
    protected $fillable=['fullname','email','number','ordernumber','inquiry','subject','message','
    file'];
}
