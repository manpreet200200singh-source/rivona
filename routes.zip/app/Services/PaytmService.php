<?php

namespace App\Services;

use Anand\LaravelPaytmWallet\Facades\PaytmWallet;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class PaytmService
{
    protected $merchantKey;
    protected $merchantId;
    protected $channelId;
    protected $website;
    protected $industryTypeId;
    protected $paytmUrl;

    public function __construct()
    {
        $this->merchantKey = config('paytm.merchant_key');
        $this->merchantId = config('paytm.merchant_id');
        $this->channelId = config('paytm.channel_id', 'WEB');
        $this->website = config('paytm.website', 'WEBSTAGING');
        $this->industryTypeId = config('paytm.industry_type_id', 'Retail');
        $this->paytmUrl = config('paytm.paytm_url', 'https://securegw-stage.paytm.in/theia/processTransaction');

        // Log configuration values (without sensitive data)
        Log::info('Paytm Configuration Loaded', [
            'merchant_id' => $this->merchantId ? 'Set' : 'Not Set',
            'merchant_key' => $this->merchantKey ? 'Set' : 'Not Set',
            'channel_id' => $this->channelId,
            'website' => $this->website,
            'industry_type' => $this->industryTypeId,
            'paytm_url' => $this->paytmUrl
        ]);

        // Validate required configuration
        if (empty($this->merchantKey) || empty($this->merchantId)) {
            throw new \RuntimeException('Paytm configuration is incomplete. Please check your .env file.');
        }
    }

    public function initiatePayment($order)
    {
        try {
            // Log order data
            Log::info('Initiating Paytm Payment', [
                'order_id' => $order->id ?? 'Not Set',
                'user_id' => $order->user_id ?? 'Not Set',
                'total' => $order->total ?? 'Not Set',
                'phone' => $order->phone ?? 'Not Set',
                'email' => auth()->user()->email ?? 'Not Set'
            ]);

            if (!$order || !$order->id || !$order->user_id || !$order->total) {
                throw new \Exception('Invalid order data');
            }

            $payment = PaytmWallet::with('receive');
            
            $paymentData = [
                'order' => $order->id,
                'user' => $order->user_id,
                'mobile_number' => $order->phone ?? '',
                'email' => auth()->user()->email ?? '',
                'amount' => $order->total,
                'callback_url' => route('paytm.callback')
            ];

            // Log payment data
            Log::info('Preparing Paytm Payment Data', $paymentData);

            // Validate payment data
            if (empty($paymentData['order']) || empty($paymentData['user']) || empty($paymentData['amount'])) {
                throw new \Exception('Required payment data is missing');
            }

            $payment->prepare($paymentData);
            $response = $payment->receive();
            
            // Log response
            Log::info('Paytm Payment Response', ['response' => $response]);

            return $response;
        } catch (\Exception $e) {
            Log::error('Paytm Payment Initiation Error: ' . $e->getMessage(), [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    public function verifyPayment($request)
    {
        try {
            if (!$request) {
                Log::error('Paytm Payment Verification Error: Empty request received');
                return false;
            }

            $transaction = PaytmWallet::with('receive');
            $response = $transaction->response();
            
            if (!$response) {
                Log::error('Paytm Payment Verification Error: Empty response received');
                return false;
            }

            return $transaction->isSuccessful();
        } catch (\Exception $e) {
            Log::error('Paytm Payment Verification Error: ' . $e->getMessage());
            return false;
        }
    }
} 