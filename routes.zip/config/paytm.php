<?php

return [
    'merchant_key' => env('PAYTM_MERCHANT_KEY'),
    'merchant_id' => env('PAYTM_MERCHANT_ID'),
    'channel_id' => env('PAYTM_CHANNEL_ID', 'WEB'),
    'website' => env('PAYTM_WEBSITE', 'WEBSTAGING'),
    'industry_type_id' => env('PAYTM_INDUSTRY_TYPE_ID', 'Retail'),
    'paytm_url' => env('PAYTM_URL', 'https://securegw-stage.paytm.in/theia/processTransaction'),
]; 