<?php

use App\Models\Product;
use App\Http\Middleware\AuthAdmin;
use App\Http\Middleware\LogVisitor;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BlackController;
use App\Http\Controllers\PaytmController;
use App\Http\Controllers\QuiryController;
use App\Http\Controllers\About2Controller;
use App\Http\Controllers\PolicyController;
use App\Http\Controllers\RatingController;
use App\Http\Controllers\WishlistController;

use App\Http\Controllers\VisitorController;

Route::get('/test', function () { return 'Hello World'; });

Route::get('/visitors', [VisitorController::class, 'index']);
Route::post('/visitors', [VisitorController::class, 'store']);
// Public Routes
Route::get('/', [HomeController::class, 'index'])->name('home.index')->middleware(LogVisitor::class);
Route::get('/shop', [ShopController::class, 'index'])->name('shop.index');
Route::get('/shop/{product_slug}', [ShopController::class, 'product_details'])->name('shop.product.details');
Route::get('/about', [AboutController::class, 'index'])->name('about_show');
Route::get('/about_form', [About2Controller::class, 'index'])->name('about_form');
Route::get('/about/table', [About2Controller::class, 'create'])->name('about_table');
Route::get('contact-us', [HomeController::class, 'contact'])->name('home.contact');
Route::get('/search', [HomeController::class, 'search'])->name('home.search');
Route::post('/contact/store', [HomeController::class, 'contact_store'])->name('home.contact.store');
Route::post('/about/store', [About2Controller::class, 'store'])->name('about_store');
Route::get('/about/delete/{id}', [About2Controller::class, 'destroy'])->name('about_delete');
Route::get('/about/edit/{id}', [About2Controller::class, 'edit'])->name('about_edit');
Route::post('/about/update/{id}', [About2Controller::class, 'update'])->name('about_update');



// PolicyController
Route::get('/policy', [PolicyController::class, 'create'])->name('policy');

// Authentication Routes
Auth::routes();

// User Routes (Authenticated)
Route::middleware(['auth'])->group(function () {
    // User Dashboard
    Route::get('/account-dashboard', [UserController::class, 'index'])->name('user.index');
    Route::get('/account-orders', [UserController::class, 'orders'])->name('user.orders');
    Route::get('/account-order/{order_id}/details', [UserController::class, 'order_details'])->name('user.order.details');
    Route::post('/order-cancel', [UserController::class, 'order_cancel'])->name('user.order.cancel');

    // Cart Routes
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart/add', [CartController::class, 'add_to_cart'])->name('cart.add');
    Route::put('cart/increase-quantity/{rowId}', [CartController::class, 'increase_cart_quantity'])->name('cart.qty.increase');
    Route::put('cart/decrease-quantity/{rowId}', [CartController::class, 'decreace_cart_quantity'])->name('cart.qty.decrease');
    Route::delete('cart/remove/{rowId}', [CartController::class, 'remove_item'])->name('cart.item.remove');
    Route::delete('/cart/clear', [CartController::class, 'empty_cart'])->name('cart.empty');
    Route::post('cart/apply-coupon', [CartController::class, 'apply_coupon_code'])->name('cart.coupon.apply');
    Route::delete('cart/remove-coupon', [CartController::class, 'remove_coupon_code'])->name('cart.coupon.remove');
    Route::get('checkout', [CartController::class, 'checkout'])->name('cart.checkout');
    Route::post('/place-an-order', [CartController::class, 'place_an_order'])->name('cart.place.an.order');
    Route::get('/order-confirmation', [CartController::class, 'order_confirmation'])->name('cart.order.confirmation');
    Route::get('/order-confirmation-stripe', [CartController::class, 'orderSuccess'])->name('cart.order.stripe.confirmation');//page create karna aa gurpreet yaad rakhi

    // Wishlist Routes
    Route::Post('/wishlist/add', [WishlistController::class, 'add_to_wishlist'])->name('wishlist.add');
    Route::get('/wishlist', [WishlistController::class, 'index'])->name('wishlist.index');
    Route::delete('/wishlist/item/remove/{rowId}', [WishlistController::class, 'remove_item'])->name('wishlist.remove.item');
    Route::delete('/wishlist/clear', [WishlistController::class, 'empty_wishlist'])->name('wishlist.items.clear');
    Route::post('/wishlist/move-to-cart/{rowId}', [WishlistController::class, 'move_to_cart'])->name('wishlist.move.to.cart');
});

// Admin Routes (Authenticated + Admin Middleware)
Route::middleware(['auth', AuthAdmin::class])->group(function () {
    // Admin Dashboard
    Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
    Route::get('/admin/search', [AdminController::class, 'search'])->name('admin.search');

    // Brand Routes
    Route::get('/admin/brands', [AdminController::class, 'brands'])->name('admin.brands');
    Route::get('/admin/brand/add', [AdminController::class, 'add_brand'])->name('admin.brand.add');
    Route::post('/admin/brand/store', [AdminController::class, 'brand_store'])->name('admin.brand.store');
    Route::get('/admin/brand/edit/{id}', [AdminController::class, 'brand_edit'])->name('admin.brand.edit');
    Route::put('/admin/brand/update', [AdminController::class, 'brand_update'])->name('admin.brand.update');
    Route::delete('/admin/brand/delete/{id}', [AdminController::class, 'brand_delete'])->name('admin.brand.delete');

    // Category Routes
    Route::get('/admin/categories', [AdminController::class, 'categories'])->name('admin.categories');
    Route::get('/admin/categories/add', [AdminController::class, 'categories_add'])->name('admin.categories.add');
    Route::post('/admin/categories/store', [AdminController::class, 'categories_store'])->name('admin.categories.store');
    Route::get('/admin/categories/edit/{id}', [AdminController::class, 'categories_edit'])->name('admin.categories.edit');
    Route::put('/admin/categories/update', [AdminController::class, 'categories_update'])->name('admin.categories.update');
    Route::delete('/admin/categories/delete/{id}', [AdminController::class, 'categories_delete'])->name('admin.categories.delete');

    // Product Routes
    Route::get('admin/products', [AdminController::class, 'products'])->name('admin.products');
    Route::get('/admin/products/add', [AdminController::class, 'product_add'])->name('admin.products.add');
    Route::Post('/admin/product/store', [AdminController::class, 'products_store'])->name('admin.product.store');
    Route::get('/admin/product/edit/{id}', [AdminController::class, 'product_edit'])->name('admin.product.edit');
    Route::put('/admin/product/update/{id}', [AdminController::class, 'product_update'])->name('admin.product.update');
    Route::delete('/admin/product/delete/{id}', [AdminController::class, 'product_delete'])->name('admin.product.delete');
    //count product route
    Route::get('/products/{id}/quantity', [AdminController::class, 'getQuantity']);


    // Order Routes
    Route::get('/admin/orders', [AdminController::class, 'orders'])->name('admin.orders');
    Route::get('/admin/orders/{order_id}/details', [AdminController::class, 'order_details'])->name('admin.order.details');
    Route::put('/admin/order/update-status', [AdminController::class, 'update_order_status'])->name('admin.order.status.update');

    // Coupon Routes
    Route::get('/admin/coupons', [AdminController::class, 'Coupons'])->name('admin.coupons');
    Route::get('/admin/coupon/add', [AdminController::class, 'coupon_add'])->name('admin.coupon.add');
    Route::post('/admin/coupon/store', [AdminController::class, 'coupon_store'])->name('admin.coupon.store');
    Route::get('/admin/coupon/{id}/edit', [AdminController::class, 'coupon_edit'])->name('admin.coupon.edit');
    Route::put('/admin/coupon/update', [AdminController::class, 'coupon_update'])->name('admin.coupon.update');
    Route::get('/admin/coupon/{id}/delete', [AdminController::class, 'coupon_delete'])->name('admin.coupon.delete');

    // Slide Routes
    Route::get('/admin/slides', [AdminController::class, 'slides'])->name('admin.slides');
    Route::get('/admin/slide/add', [AdminController::class, 'slide_add'])->name('admin.slide.add');
    Route::post('/admin/slide/store', [AdminController::class, 'slide_store'])->name('admin.slide.store');
    Route::get('/admin/slide/{id}/edit', [AdminController::class, 'slide_edit'])->name('admin.slide.edit');
    Route::put('/admin/slide/update', [AdminController::class, 'slide_update'])->name('admin.Slide.Update');
    Route::get('admin/slide/delete/{id}', [AdminController::class, 'slide_delete'])->name('admin.slide.delete');

    // Contact Routes
    Route::get('/admin/contact', [AdminController::class, 'contacts'])->name('admin.contacts');
    Route::get('admin/contact/delete/{id}', [AdminController::class, 'contact_delete'])->name('admin.contact.delete');
});

Route::get('/blackslider',[BlackController::class,'create'])->name('blackslider');
Route::post('/blacksliderstore',[BlackController::class,'store'])->name('blacksliderstore');
Route::get('/blackslidershow',[BlackController::class,'index'])->name('blackslidershow');

Route::get('/blackedit/{id}',[BlackController::class,'edit'])->name('blackedit');
Route::post('/blackupdate/{id}',[BlackController::class,'update'])->name('blackupdate');
Route::get('/blackdelete{id}', [BlackController::class, 'destroy'])->name('blackdelete');

Route::get('/query',[QuiryController::class,'create'])->name('query');
Route::post('/inquirystore',[QuiryController::class,'store'])->name('inquirystore');
Route::get('/inquirytable',[QuiryController::class,'index'])->name('inquirytable');
Route::get('/inquirydelete/{id}',[QuiryController::class,'destroy'])->name('inquirydelete');


Route::get('/test',function(){

    $product = Product::findOrFail(1   );
    return  $product->quantity;
})->name('test');
// Paytm Routes
// Route::post('/paytm/callback', [PaytmController::class, 'callback'])->name('paytm.callback');

// //rating
// Route::post('/ratings', [RatingController::class, 'store'])->name('ratings.store');
Route::post('/rate', [RatingController::class, 'store'])->name('rate.store');

Route::get('/product/{productId}/ratings', [AdminController::class, 'getProductRatings'])->name('product.ratings');

