-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2025 at 12:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel11db`
--

-- --------------------------------------------------------

--
-- Table structure for table `about2s`
--

CREATE TABLE `about2s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pic` varchar(255) NOT NULL,
  `story` longtext NOT NULL,
  `mission` longtext NOT NULL,
  `vision` longtext NOT NULL,
  `company` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about2s`
--

INSERT INTO `about2s` (`id`, `pic`, `story`, `mission`, `vision`, `company`, `created_at`, `updated_at`) VALUES
(8, '1755353820.jpg', 'Welcome to rivona.co.uk – Your One-Stop DVD Destination At rivona.co.uk, we believe every great movie deserves a place in your collection. Our eCommerce store offers a vast and carefully curated selection of DVDs, catering to movie enthusiasts, casual viewers, and serious collectors alike. Whether you’re searching for timeless classics, award-winning masterpieces, cult favorites, or the latest blockbusters, you’ll find them all in one convenient online location.', 'Our Mission Our mission is to keep the magic of physical media alive by providing movie lovers with a diverse, high-quality selection of DVDs at affordable prices. We aim to create a convenient and enjoyable shopping experience where every customer can discover, collect, and cherish the films they love. By offering everything from timeless classics to the latest releases, we strive to connect people with stories that inspire, entertain, and bring joy — all delivered right to their doorstep.', 'Our vision Our vision is to become the go-to online destination for movie enthusiasts worldwide, preserving the joy of physical media in an increasingly digital age. We aspire to build a thriving community of collectors and film lovers who value owning timeless stories they can watch, share, and treasure for years to come. By continually expanding our collection, embracing emerging genres, and delivering outstanding customer service, we aim to keep the art of cinema alive — one DVD at a time.', 'The company rivona.co.uk is an online DVD store offering a wide range of movies and TV shows across all genres. From timeless classics to the latest releases, we deliver high-quality DVDs at affordable prices, with secure shopping and fast delivery for movie lovers everywhere.', '2025-08-16 21:08:16', '2025-08-16 21:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `locality` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'home',
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `name`, `phone`, `locality`, `city`, `state`, `address`, `country`, `zip`, `landmark`, `type`, `isdefault`, `created_at`, `updated_at`) VALUES
(6, 3, 'Aman', '9464940245', 'a', 'tanda', 'punjab', 'a', 'India', '144210', 'aa', 'home', 1, '2025-08-20 12:08:21', '2025-08-20 12:08:21'),
(7, 5, 'gurpreet kaur', '9464940245', 'pathankot road', 'tanda', 'Punjab', '123', 'India', '144210', 'ravidas gurughar', 'home', 1, '2025-10-10 23:29:52', '2025-10-10 23:29:52');

-- --------------------------------------------------------

--
-- Table structure for table `blacks`
--

CREATE TABLE `blacks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blacks`
--

INSERT INTO `blacks` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(5, 'Spider Man-2', '\"I believe there\'s a hero in all of us, that keeps us honest, gives us strength, makes us noble.\"', '1752554044.jpeg', '2025-07-14 22:52:14', '2025-07-14 23:04:04'),
(6, 'All Of Us Are Dead', 'Nam On-jo: \"We have to survive, no matter what!\", Lee Su-hyeok: \"We can\'t give up hope, even in the darkest times.\"', '1752554213.jpeg', '2025-07-14 22:54:34', '2025-07-14 23:06:53'),
(7, 'Avengers End Game', '\"Avengers: Endgame\" is the climactic conclusion to the Infinity Saga, where the remaining Avengers unite to reverse the devastation caused by Thanos. The film explores themes of sacrifice, heroism, and the enduring bonds of friendship among the heroes.', '1752554545.jpg', '2025-07-14 23:12:25', '2025-07-14 23:12:25');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(5, 'Chris Lang', 'chris-lang', '1747911846.jpg', '2025-05-22 05:34:06', '2025-05-22 05:34:06'),
(6, 'Wan,James', 'wanjames', '1747912929.jpg', '2025-05-22 05:52:11', '2025-05-22 05:52:11'),
(7, 'Ayub Khan Din', 'ayub-khan-din', '1748408373.jpg', '2025-05-27 23:27:35', '2025-05-27 23:29:33'),
(8, 'Documentary', 'documentary', '1748583379.jpg', '2025-05-30 00:06:19', '2025-05-30 00:06:19'),
(9, 'Action', 'action', '1748857814.jpg', '2025-06-02 04:20:14', '2025-06-02 04:20:14'),
(10, 'Supernatural Horror', 'supernatural-horror', '1748859680.jpg', '2025-06-02 04:51:20', '2025-06-02 04:51:20'),
(11, 'Comedy', 'comedy', '1749012143.jpg', '2025-06-03 23:12:26', '2025-06-03 23:12:26'),
(12, 'Historical Drama', 'historical-drama', '1749022300.jpg', '2025-06-04 02:01:40', '2025-06-04 02:01:40'),
(14, 'Warner Bros', 'warner-bros', '1756897980.jpg', '2025-06-04 02:44:21', '2025-09-03 05:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `image`, `parent_id`, `created_at`, `updated_at`) VALUES
(7, 'Horror', 'horror', '1747910825.jpg', NULL, '2025-05-22 05:17:08', '2025-05-22 05:17:08'),
(8, 'Adventure', 'adventure', '1747910920.jpg', NULL, '2025-05-22 05:18:40', '2025-05-22 05:18:40'),
(10, 'Crime Drama', 'crime-drama', '1747911223.jpg', NULL, '2025-05-22 05:23:43', '2025-05-22 05:23:43'),
(11, 'ADVENTURE AND FANTASY', 'adventure-and-fantasy', '1748406796.jpg', NULL, '2025-05-27 23:03:16', '2025-05-27 23:03:16'),
(12, 'comedy-drama', 'comedy-drama', '1748408226.jpg', NULL, '2025-05-27 23:27:08', '2025-05-27 23:27:08'),
(13, 'Documentary', 'documentary', '1748583361.jpg', NULL, '2025-05-30 00:06:04', '2025-05-30 00:06:04'),
(14, 'Action', 'action', '1748857795.jpg', NULL, '2025-06-02 04:19:58', '2025-06-02 04:19:58'),
(15, 'Supernatural Horror', 'supernatural-horror', '1748859642.jpg', NULL, '2025-06-02 04:50:42', '2025-06-02 04:50:42'),
(16, 'Historical Drama', 'historical-drama', '1749022276.jpg', NULL, '2025-06-04 02:01:18', '2025-06-04 02:01:18'),
(17, 'Thriller', 'thriller', '1749024843.jpg', NULL, '2025-06-04 02:44:03', '2025-06-04 02:44:03'),
(18, '4K UHD BLU-RAY', '4k-uhd-blu-ray', '1756896328.jpg', NULL, '2025-09-03 05:15:31', '2025-09-03 05:15:31'),
(19, 'BLU-RAY', 'blu-ray', '1756896622.jpg', NULL, '2025-09-03 05:20:23', '2025-09-03 05:20:23'),
(20, 'BLU-RAY 3D', 'blu-ray-3d', '1756896737.jpg', NULL, '2025-09-03 05:22:17', '2025-09-03 05:22:17'),
(21, 'CASES', 'cases', '1756896965.jpg', NULL, '2025-09-03 05:26:05', '2025-09-03 05:26:05'),
(22, 'CD', 'cd', '1756896980.jpg', NULL, '2025-09-03 05:26:20', '2025-09-03 05:26:20'),
(23, 'DVD', 'dvd', '1756896998.jpg', NULL, '2025-09-03 05:26:38', '2025-09-03 05:26:38'),
(24, 'PS4 GAMES', 'ps4-games', '1756897033.jpg', NULL, '2025-09-03 05:27:14', '2025-09-03 05:27:14'),
(25, 'TURNTABLES', 'turntables', '1756897181.jpg', NULL, '2025-09-03 05:29:41', '2025-09-03 05:29:41'),
(26, 'VINIL RECODS', 'vinil-recods', '1756897207.jpg', NULL, '2025-09-03 05:30:07', '2025-09-03 05:30:07'),
(27, 'WIRELESS HEADPHONES', 'wireless-headphones', '1756897242.jpg', NULL, '2025-09-03 05:30:42', '2025-09-03 05:30:42'),
(28, 'XBOX ONE', 'xbox-one', '1756897265.jpg', NULL, '2025-09-03 05:31:06', '2025-09-03 05:31:06');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `comment`, `created_at`, `updated_at`) VALUES
(4, 'Una Ivey', 'una.ivey62@yahoo.com', '7818916164', 'Hi,\r\n\r\nFor rivona.co.uk to be displayed in search results, it needs to be indexed.\r\n\r\nTo add it now to Google Index, visit https://SearchRegister.info', '2025-08-07 00:18:52', '2025-08-07 00:18:52'),
(5, 'Delores Cassell', 'delores.cassell@hotmail.com', '4032403551', 'Hi,\r\n\r\njoin our Search Engine - optmized directory for a quick improvement in traffic.\r\n\r\n\r\nAdd rivona.co.uk to SEODIRECTORY now:\r\n\r\n\r\nhttps://seodirectory.site', '2025-08-08 02:43:10', '2025-08-08 02:43:10'),
(6, 'Search Index', 'registration@search-lndex.net', '4146906453', 'Hi,\r\n\r\nadd rivona.co.uk to Google Search Index and have it displayed in search results. Visit now:\r\n\r\nhttps://SearchRegister.info/', '2025-08-27 01:34:54', '2025-08-27 01:34:54');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `type` enum('fixed','percent') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `cart_value` decimal(10,2) NOT NULL,
  `expiry_date` date NOT NULL DEFAULT cast(current_timestamp() as date),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(37, '0001_01_01_000000_create_users_table', 1),
(38, '0001_01_01_000001_create_cache_table', 1),
(39, '0001_01_01_000002_create_jobs_table', 1),
(40, '2025_02_21_104454_create_brands_table', 1),
(41, '2025_02_25_051210_create_categories_table', 1),
(42, '2025_02_25_070702_create_products_table', 1),
(43, '2025_03_10_102502_create_abouts_table', 1),
(44, '2025_03_15_052943_create_coupons_table', 1),
(45, '2025_04_02_102108_create_addresses_table', 1),
(46, '2025_04_02_102406_create_order_items_table', 1),
(47, '2025_04_02_102421_create_orders_table', 1),
(48, '2025_04_03_063451_create_transactions_table', 1),
(49, '2025_04_19_103226_create_slides_table', 2),
(50, '2025_04_21_111638_create_month_names_table', 3),
(51, '2025_04_22_072056_create_contacts_table', 4),
(52, '2025_04_23_045609_create_about2s_table', 5),
(53, '2025_07_14_061454_create_blacks_table', 6),
(54, '2025_07_25_052105_create_quiries_table', 7),
(55, '2025_08_30_112028_create_personal_access_tokens_table', 8),
(56, '2025_09_10_104544_create_ratings_table', 8),
(57, '2025_09_12_093917_create_ratings_table', 9),
(58, '2025_10_31_084544_create_wishlists_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `month_names`
--

CREATE TABLE `month_names` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `month_names`
--

INSERT INTO `month_names` (`id`, `name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'Octuber'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(8,2) NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `locality` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'home',
  `status` enum('ordered','delivered','canceled') NOT NULL DEFAULT 'ordered',
  `is_shipping_different` tinyint(1) NOT NULL DEFAULT 0,
  `delivered_date` date DEFAULT NULL,
  `canceled_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `subtotal`, `discount`, `tax`, `total`, `name`, `phone`, `locality`, `address`, `city`, `state`, `country`, `zip`, `landmark`, `type`, `status`, `is_shipping_different`, `delivered_date`, `canceled_date`, `created_at`, `updated_at`) VALUES
(22, 3, 49.98, 0.00, 10.50, 60.48, 'Aman', '9464940245', 'a', 'a', 'tanda', 'punjab', 'India', '144210', 'aa', 'home', 'delivered', 0, '2025-10-11', NULL, '2025-10-10 23:26:24', '2025-10-10 23:27:57'),
(23, 5, 16.99, 0.00, 3.57, 20.56, 'gurpreet kaur', '9464940245', 'pathankot road', '123', 'tanda', 'Punjab', 'India', '144210', 'ravidas gurughar', 'home', 'canceled', 0, NULL, '2025-10-11', '2025-10-10 23:29:52', '2025-10-10 23:33:54');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `options` longtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `price`, `quantity`, `options`, `status`, `created_at`, `updated_at`, `product_id`, `order_id`) VALUES
(22, 24.99, 2, NULL, 0, '2025-10-10 23:26:24', '2025-10-10 23:26:24', '56', '22'),
(23, 16.99, 1, NULL, 0, '2025-10-10 23:29:52', '2025-10-10 23:29:52', '12', '23');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `released_date` varchar(255) DEFAULT NULL,
  `region_code` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_description` longtext DEFAULT NULL,
  `description` longtext NOT NULL,
  `regular_price` decimal(8,2) NOT NULL,
  `sale_price` decimal(8,2) DEFAULT NULL,
  `SKU` varchar(255) NOT NULL,
  `stock_status` enum('instock','outofstock') NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 10,
  `image` varchar(255) DEFAULT NULL,
  `images` text DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `brand_id` bigint(20) UNSIGNED DEFAULT NULL,
  `productcode` varchar(255) NOT NULL,
  `barcode` varchar(255) NOT NULL,
  `language` longtext NOT NULL,
  `duration` varchar(255) NOT NULL,
  `barcode_img` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `released_date`, `region_code`, `slug`, `short_description`, `description`, `regular_price`, `sale_price`, `SKU`, `stock_status`, `featured`, `quantity`, `image`, `images`, `category_id`, `brand_id`, `productcode`, `barcode`, `language`, `duration`, `barcode_img`, `created_at`, `updated_at`) VALUES
(5, 'Unforgotten - Series 1 - 4 Boxset [DVD] [2021]', '0', '0', 'unforgotten-series-1-4-boxset-dvd-2021', '\"Unforgotten\" is a British crime drama series that follows detectives as they investigate cold cases involving historical murders. Each season delves into a new case, revealing the complexities of human relationships and the long-lasting impact of crime on victims and their families.', '\"Unforgotten\" is a critically acclaimed British crime drama series that premiered in 2015. Created by Chris Lang, the show centers around detectives in London who specialize in solving cold cases—murders that have remained unresolved for years. Each season introduces a new case, intricately weaving together the lives of the victims, their families, and the suspects, as the detectives work to uncover the truth behind the crimes.\r\n\r\nThe series is led by DI Sunil \'Sunny\' Khan (played by Sanjeev Bhaskar) and his partner, DS Cassie Stuart (played by Nicola Walker), who navigate the emotional and psychological complexities of each investigation. As they delve into the past, they confront the long-lasting effects of the crimes on all involved, exploring themes of guilt, redemption, and the quest for justice.\r\n\r\n\"Unforgotten\" is praised for its strong character development, compelling storytelling, and its ability to tackle sensitive subjects with depth and nuance. The show has garnered numerous awards and nominations, solidifying its place as a standout in the crime drama genre. With its engaging plots and rich character arcs, \"Unforgotten\" captivates audiences while shedding light on the often-overlooked stories of victims and their families.', 48.99, 43.12, 'test sku', 'instock', 0, 1, '1747911859.jpg', '1748579186-1.jpg,1748579186-2.jpeg,1748579186-3.jpeg', 10, 5, '', '', '0', '', '', '2025-05-22 05:34:20', '2025-05-29 22:56:29'),
(6, 'The Conjuring', '0', '0', 'the-conjuring', 'The Conjuring\" follows paranormal investigators Ed and Lorraine Warren as they help a family terrorized by a dark presence in their farmhouse.', 'In this chilling horror film, Ed and Lorraine Warren, renowned paranormal investigators, are called to assist the Perron family, who are experiencing increasingly disturbing events in their Rhode Island farmhouse. As they delve deeper into the haunting, they uncover a malevolent entity that threatens not only the family but also their own lives. The film is based on true events and showcases the Warrens\' dedication to helping those afflicted by supernatural forces.', 8.49, 4.63, '1 - 4  [DVD]', 'instock', 0, 1, '1747913306.jpg', '1748079940-1.jpg', 7, 10, '', '', '0', '', '', '2025-05-22 05:58:29', '2025-06-18 02:22:57'),
(7, 'Beauty and the Beast', '0', '0', 'beauty-and-the-beast', '\"Beauty and the Beast\" tells the story of Belle, a young woman who becomes a prisoner in a castle inhabited by a Beast. The Beast, cursed to remain in his monstrous form until he learns to love and be loved in return, finds his life transformed when Belle enters his world. Through their journey, they discover the true meaning of love and acceptance.', '\"Beauty and the Beast\" is a timeless fairy tale that originated from French folklore, with the most famous version written by Gabrielle-Suzanne Barbot de Villeneuve in the 18th century and later abridged and rewritten by Jeanne-Marie Leprince de Beaumont. The story centers around Belle, a bright and independent young woman who feels out of place in her provincial village.\r\n\r\nWhen her father, Maurice, is captured by a Beast while wandering in the woods, Belle bravely offers to take his place as the Beast\'s prisoner. The Beast, once a handsome prince, was cursed by an enchantress for his selfishness and must learn to love and earn love in return to break the spell.\r\n\r\nAs Belle and the Beast spend time together, they begin to form an unlikely bond. With the help of the enchanted household objects in the castle, such as Lumière, Cogsworth, and Mrs. Potts, Belle discovers the Beast\'s kind heart beneath his gruff exterior.\r\n\r\nThe story explores themes of inner beauty, redemption, and the transformative power of love. Ultimately, Belle\'s love helps the Beast break the curse, restoring him to his true form and allowing them to live happily ever after.\r\n\r\nThe most notable adaptations include Disney\'s animated film released in 1991, which received critical acclaim and became a cultural phenomenon, and the live-action adaptation released in 2017, starring Emma Watson as', 34.99, 33.98, '1 - 2 Boxset [DVD]', 'instock', 1, 1, '1747989416.jpg', '1748080229-1.jpg', 8, 5, '', '', '0', '', '', '2025-05-23 03:06:57', '2025-05-24 04:20:30'),
(8, 'Paddington in Peru', '0', '0', 'paddington-in-peru', 'Paddington in Peru\" follows the beloved marmalade-loving bear as he embarks on a thrilling adventure to find his missing Aunt Lucy, leading him and the Brown family into the jungles of Peru.', 'In \"Paddington in Peru,\" the third installment of the beloved series, Paddington discovers that his Aunt Lucy has gone missing from the Home for Retired Bears. Determined to find her, he sets off on an exciting journey to Peru with the Brown family. Along the way, they encounter various challenges and adventures, showcasing the importance of family, friendship, and courage. The film beautifully captures the vibrant landscapes of Peru and the heartwarming spirit of Paddington as he navigates through this high-stakes quest.', 20.99, 19.99, 'DVD', 'instock', 1, 1, '1747995168.jpg', '1747995168-1.jpeg', 8, 5, '', '', '0', '', '', '2025-05-23 04:42:51', '2025-05-23 04:42:51'),
(9, 'Paddington 2', '0', '0', 'paddington-2', 'In \"Paddington 2,\" the lovable bear embarks on a quest to retrieve a stolen pop-up book, leading to a series of hilarious adventures as he tries to clear his name and make Aunt Lucy\'s birthday special.', '\"Paddington 2\" follows Paddington, who is now happily living with the Brown family in Windsor Gardens. Eager to buy a unique pop-up book for Aunt Lucy\'s birthday, he takes on various odd jobs. However, when the book is stolen, Paddington must team up with the Browns to catch the thief and prove his innocence, all while spreading joy and kindness throughout the community.', 19.99, 14.99, 'Paddington 2  DVD)', 'outofstock', 1, 1, '1747995473.jpg', '1747995473-1.jpeg', 8, 5, '', '', '0', '', '', '2025-05-23 04:47:54', '2025-05-23 04:47:54'),
(10, 'Paddington', '0', '0', 'paddington', '\"Paddington\" tells the charming story of a small bear from Peru who arrives in London, where he is found by the Brown family at Paddington Station, leading to delightful adventures filled with humor and warmth.', 'In \"Paddington,\" a young bear from Darkest Peru travels to London in search of a new home. Armed with only a suitcase and a love for marmalade, he is discovered by the Brown family at Paddington Station. As they take him in, Paddington\'s innocent antics and misadventures bring joy and chaos to their lives, showcasing themes of family, kindness, and acceptance.', 20.99, 15.99, 'Paddington (Hardcover)', 'outofstock', 0, 1, '1747995654.jpg', '1747995654-1.jpeg', 8, 5, '', '', '0', '', '', '2025-05-23 04:50:54', '2025-05-23 04:50:54'),
(11, 'The Conjuring 2', '0', '0', 'the-conjuring-2', 'The Conjuring 2\" is a supernatural horror film directed by James Wan, following paranormal investigators Ed and Lorraine Warren as they help a family in London plagued by a malevolent spirit.', 'In this chilling sequel, set in 1977, Ed and Lorraine Warren travel to north London to assist a single mother and her four children, who are experiencing terrifying supernatural occurrences in their home. The film delves into the infamous Enfield Poltergeist case, showcasing the Warrens\' struggle against dark forces while exploring themes of faith and family.', 8.25, 6.25, 'Blu-ray and DVD', 'instock', 1, 1, '1748080548.jpg', '1748080548-1.jpg', 7, 10, '', '', '0', '', '', '2025-05-24 04:25:49', '2025-06-18 02:22:39'),
(12, 'THE CONJURING (THE DEVIL MADE ME DO IT)', '0', '0', 'the-conjuring-the-devil-made-me-do-it', 'The Conjuring: The Devil Made Me Do It\" is a supernatural horror film that follows Ed and Lorraine Warren as they investigate a chilling case of demonic possession linked to a murder trial.', 'This film, based on a true story, explores one of the most sensational cases from the Warrens\' files, where a young man claims demonic possession as a defense for murder. As they delve deeper, Ed and Lorraine confront a malevolent force that challenges their faith and their lives, revealing the dark side of the supernatural.', 18.99, 16.99, '4K Ultra HD + Blu-ray', 'instock', 0, 1, '1748080774.jpg', '1748080774-1.jpg', 7, 10, '', '', '0', '', '', '2025-05-24 04:29:34', '2025-06-18 02:21:35'),
(13, 'The Conjuring ANNABELLE(TRULY TRIGHTENING)', '0', '0', 'the-conjuring-annabelletruly-trightening', 'Annabelle\" is a horror film that serves as a prequel to \"The Conjuring,\" focusing on a couple who experiences terrifying supernatural events linked to a vintage doll.', 'Set in the 1970s, \"Annabelle\" follows Mia and John Gordon, who are haunted by a malevolent force after their home is invaded by satanic cultists. The couple soon discovers that the doll, Annabelle, is the source of their nightmares, leading to a battle against dark forces that threaten their lives and sanity.', 12.25, 9.99, 'the DVD version', 'instock', 1, 1, '1748081694.jpg', '1748081694-1.jpg', 7, 5, '', '', '0', '', '', '2025-05-24 04:44:57', '2025-05-24 04:44:57'),
(14, 'Annabelle: Creation', '0', '0', 'annabelle-creation', 'Annabelle: Creation\" is a horror film that serves as a prequel to \"Annabelle,\" detailing the origins of the cursed doll and the tragic events that unfold in a dollmaker\'s home.', 'Set years after the tragic death of their daughter, a dollmaker and his wife welcome a nun and several girls from a shuttered orphanage into their home. However, they soon become the target of Annabelle, the possessed doll, unleashing a series of terrifying supernatural occurrences that threaten their lives.', 8.49, 4.68, 'The DVD version', 'instock', 0, 1, '1748083386.jpg', '1748083386-1.jpeg', 7, 5, '', '', '0', '', '', '2025-05-24 04:50:08', '2025-05-24 05:13:07'),
(15, 'WELCOME TO THE HOME OF THE CONJURING UNIVERSE Annabelle', '0', '0', 'welcome-to-the-home-of-the-conjuring-universe-annabelle', 'Annabelle: Creation\" is a horror film that serves as a prequel to \"Annabelle,\" detailing the origins of the cursed doll and the tragic events that unfold in a dollmaker\'s home.', 'Set years after the tragic death of their daughter, a dollmaker and his wife welcome a nun and several girls from a shuttered orphanage into their home. However, they soon become the target of Annabelle, the possessed doll, unleashing a series of terrifying supernatural occurrences that threaten their lives.', 8.49, 4.99, 'The DVD version', 'instock', 1, 1, '1748082462.jpg', '1748082462-1.jpg', 7, 5, '', '', '0', '', '', '2025-05-24 04:57:43', '2025-05-24 04:57:43'),
(16, 'THE COURSE OF LALLORONA', '0', '0', 'the-course-of-lallorona', 'The Curse of La Llorona\" is a horror film that brings to life the chilling Hispanic legend of La Llorona, a ghostly figure who preys on children and haunts those who hear her weeping.', 'The story follows a social worker who, after ignoring the warnings of a troubled mother, finds herself and her children in grave danger as La Llorona seeks to claim them. As supernatural events unfold, she must confront the terrifying force that threatens her family and unravel the mystery behind the curse.', 8.49, 4.99, 'The DVD version', 'instock', 1, 1, '1748083782.jpg', '1748083782-1.jpeg', 7, 5, '', '', '0', '', '', '2025-05-24 05:19:43', '2025-05-24 05:19:43'),
(17, 'MOANA', '0', '0', 'moana', 'Moana is an animated adventure about a spirited teen who embarks on a daring mission to save her people, teaming up with the demigod Maui.', 'Set in ancient Polynesia, Moana tells the story of Moana Waialiki, the chief\'s daughter, who is chosen by the ocean to restore the heart of Te Fiti. Along her journey, she encounters the demigod Maui, navigates the vast ocean, and discovers her true identity and destiny.', 18.99, 14.99, 'DVD', 'instock', 1, 1, '1748404557.jpg', '1748404557-1.jpeg', 8, 6, '', '', '0', '', '', '2025-05-27 22:26:01', '2025-05-27 22:31:23'),
(18, 'MOANA 2', '0', '0', 'moana-2', 'Moana 2 continues the animated musical journey of Moana and Maui, who reunite three years later for a new adventure filled with excitement and discovery.', 'In Moana 2, the beloved characters Moana and Maui set sail once again, embarking on an expansive voyage that introduces them to a crew of unlikely seafarers. As they navigate the challenges of the ocean, they encounter new friends and foes, all while deepening their understanding of themselves and their destinies. The film combines stunning animation with catchy musical numbers, making it a delightful experience for audiences of all ages.', 19.95, 17.95, 'DVD', 'instock', 1, 1, '1748404760.jpg', '1748404760-1.jpeg', 8, 6, '', '', '0', '', '', '2025-05-27 22:29:23', '2025-05-27 22:31:05'),
(19, 'The Father Brown Series 1 to 10 Boxset', '0', '0', 'the-father-brown-series-1-to-10-boxset', 'The Father Brown Series 1 to 10 Boxset includes all ten seasons of the beloved detective series featuring Father Brown, a priest with a knack for solving mysteries.', 'The Father Brown Series 1 to 10 Boxset compiles all ten seasons of the charming British detective series based on G.K. Chesterton\'s stories. Set in the 1950s, the series follows Father Brown, a kind-hearted priest with a deep understanding of human nature, as he solves various crimes in his quaint English village. With a mix of humor, intrigue, and moral lessons, this boxset offers a complete journey through Father Brown\'s adventures, showcasing his unique ability to uncover the truth while providing compassion and guidance to those around him.', 10.00, 99.99, '1 to 10 Boxset(DVD)', 'instock', 1, 1, '1748405439.jpg', '1748405510-1.jpg', 10, 5, '', '', '0', '', '', '2025-05-27 22:40:39', '2025-07-25 22:59:12'),
(20, 'Father Brown: Season 11', '0', '0', 'father-brown-season-11', 'Father Brown: Season 11 follows the titular priest as he solves new mysteries in 1955, including defending Sister Boniface against murder charges.', 'In Father Brown: Season 11, set in 1955, the charming clergyman sleuth returns to the picturesque Cotswolds to tackle a fresh series of intriguing mysteries. This season features a variety of cases, including a food fayre that turns deadly, a crime at a crime-writing festival, and a village rivalry that escalates dangerously. Father Brown must also prove the innocence of his old friend Sister Boniface, who is implicated in a murder at an arts and crafts fair. The season continues to explore themes of morality and human nature, all while maintaining a light-hearted tone.', 30.99, 26.99, 'DVD', 'instock', 1, 1, '1748405712.jpg', '1748405712-1.jpg', 10, 5, '', '', '0', '', '', '2025-05-27 22:45:12', '2025-05-27 22:45:12'),
(21, 'FATHER BROWN SERIES 12', '0', '0', 'father-brown-series-12', 'Father Brown: Season 12 continues the adventures of the beloved priest-detective as he solves new mysteries in the Cotswolds, tackling intriguing cases with his unique blend of compassion and wit.', 'Season 12, set in the picturesque Cotswolds, the charming priest-detective returns to face a new array of mysteries. This season features Father Brown as he investigates a series of perplexing crimes, including a murder at a local festival and a puzzling disappearance. With his deep understanding of human nature and a knack for uncovering the truth, Father Brown navigates the complexities of faith, morality, and justice, all while providing comfort and guidance to those around him. The season maintains the show\'s signature blend of humor, drama, and intrigue, making it a delightful watch for fans of the series.', 30.99, 29.15, 'DVD', 'outofstock', 1, 1, '1748406650.jpg', '1748406650-1.jpg', 10, 6, '', '', '0', '', '', '2025-05-27 22:50:52', '2025-05-27 23:00:51'),
(22, 'THE LION KING', '0', '0', 'the-lion-king', 'The Lion King is a classic animated film that follows the journey of Simba, a young lion prince, as he learns about responsibility, courage, and the circle of life after the tragic death of his father, Mufasa.', 'The Lion King, released by Disney in 1994, is a beloved animated musical that tells the story of Simba, a young lion who is destined to become king of the Pride Lands. After the untimely death of his father, Mufasa, at the hands of his treacherous uncle Scar, Simba flees into exile, believing he is responsible for the tragedy. With the help of his friends, Timon and Pumbaa, he learns to embrace a carefree lifestyle. However, as he grows older, Simba must confront his past and reclaim his rightful place as king. The film features iconic songs by Elton John and Tim Rice, including \"Circle of Life\" and \"Can You Feel the Love Tonight,\" and explores themes of identity, redemption, and the importance of family.', 17.95, 14.99, 'DVD', 'instock', 1, 1, '1748406961.jpg', '1748406961-1.jpg', 11, 5, '', '', '0', '', '', '2025-05-27 23:06:01', '2025-05-27 23:06:01'),
(23, 'MUFASA (THE LION KING)', '0', '0', 'mufasa-the-lion-king', 'Mufasa: The Lion King Novelization is the official adaptation of Disney’s 2024 animated film. Narrated through flashbacks by Rafiki, Timon, and Pumbaa, the story unveils the origins of Mufasa, the revered king of the Pride Lands. This prequel, directed by Barry Jenkins, offers a fresh perspective on the beloved character.', 'In this novelization, the tale of Mufasa\'s early life is shared with a young cub, providing insights into his journey from a curious cub to a wise and courageous leader. The narrative delves into themes of destiny, friendship, and the challenges of leadership. With a reading age of 8–12 years, the book spans 240 pages and was published by Disney Press on December 24, 2024.', 18.99, 12.70, 'DVD', 'instock', 1, 1, '1748407508.jpg', '1748407508-1.jpg', 11, 5, '', '', '0', '', '', '2025-05-27 23:15:09', '2025-05-27 23:15:09'),
(24, 'ACKLEY BRIDGE', '0', '0', 'ackley-bridge', 'Ackley Bridge is a British comedy-drama series that aired from 2017 to 2022 on Channel 4 and All 4. Set in the fictional Yorkshire town of Ackley Bridge, the show follows the lives of students and staff at a multicultural academy formed by merging a predominantly white school with an all-Asian one. It explores themes of cultural integration, identity, and community dynamics with humor and emotional depth.', 'Ackley Bridge is a British television drama that delves into the complexities of multicultural integration within a fictional Yorkshire mill town. The series centers on Ackley Bridge College, an academy formed by merging two previously segregated schools—one predominantly white and the other mostly Asian. This merger sets the stage for a rich tapestry of stories that explore the challenges and triumphs of students and staff navigating cultural divides, personal growth, and societal expectations.\r\nThe Forge+3TV Zone UK+3Wikipedia+3\r\n\r\nThe show is lauded for its authentic portrayal of modern Britain, addressing real-life issues such as racism, identity, and socio-economic struggles with a blend of irreverence and heartfelt storytelling. Characters like Nasreen Paracha (Amy-Leigh Hickman) and Missy Booth (Poppy Lee Friar) become emblematic of the series\' focus on youth, friendship, and the pursuit of dreams amidst adversity. The inclusion of characters like Kaneez Paracha (Sunetra Sarker) and Mandy Carter (Jo Joyner) adds depth, showcasing the experiences of educators and parents in a rapidly changing educational landscape.\r\nThe Forge\r\nTV Zone UK+7Wikipedia+7screenyorkshire.co.uk+7\r\n\r\nThroughout its five series, Ackley Bridge garnered critical acclaim and a dedicated fanbase, particularly among younger viewers. Its innovative storytelling and diverse representation earned it several awards, including recognition at the RTS Yorkshire Awards and the Asian Media Awards. Despite its success, Channel 4 announced in November 2022 that the series would conclude after five series, citing the need to explore new and innovative ideas.', 10.95, 5.61, 'DVD', 'instock', 1, 1, '1748408588.jpg', '1748408588-1.jpeg', 12, 7, '', '', '0', '', '', '2025-05-27 23:33:08', '2025-05-27 23:33:41'),
(25, 'ACKLEY BRIDGE SERIES 2', '0', '0', 'ackley-bridge-series-2', 'Ackley Bridge: Series Two continues the compelling drama set in the fictional Yorkshire town of Ackley Bridge. The series delves deeper into the lives of students and staff at Ackley Bridge College, exploring themes of cultural integration, identity, and personal challenges.', 'In **Ackley Bridge: Series Two**, the narrative picks up with the return of the new term at Ackley Bridge College. The series intensifies its focus on the complexities of multicultural integration within the school environment. Key storylines include Nasreen\'s struggle to conceal her sexuality behind a fake engagement, Missy\'s efforts to support her drug-addicted mother, and the introduction of a strict academic regime by headmistress Mandy Carter that causes tension among staff and students. The series continues to blend humor with poignant social commentary, offering a nuanced portrayal of contemporary British society.', 10.95, 5.61, 'DVD', 'instock', 1, 1, '1748408977.jpg', '1748408977-1.jpeg', 12, 7, '', '', '0', '', '', '2025-05-27 23:39:38', '2025-05-27 23:39:38'),
(26, 'ACKLEY BRIDGE SERIES 3', '0', '0', 'ackley-bridge-series-3', 'Ackley Bridge: Series 3 continues the engaging story of a multicultural school in Yorkshire, blending humor and drama as it explores the lives of students and staff.', 'In Ackley Bridge: Series 3, viewers are treated to eight new episodes filled with laughter, emotion, and the challenges of a diverse school environment. The series delves into the complexities of teenage life, cultural clashes, and the relationships that develop within the fictional Ackley Bridge College. As the characters navigate their personal and academic struggles, the show remains a poignant reflection on community and acceptance.', 12.99, 9.18, 'DVD', 'instock', 1, 1, '1748421930.jpg', '1748421930-1.jpg', 12, 7, '', '', '0', '', '', '2025-05-28 03:14:24', '2025-05-28 03:15:31'),
(27, 'Ackley Bridge: Series 4', '0', '0', 'ackley-bridge-series-4', 'Ackley Bridge: Series 4 features eight new episodes that blend humor and emotion in a multicultural school setting, focusing on the lives of students and staff as they tackle various challenges.', 'Ackley Bridge: Series 4 brings back the beloved characters for another round of eight episodes that are both laugh-out-loud funny and deeply emotional. The series is set in a school designed to bridge cultural divides, showcasing the challenges and triumphs of students and staff as they navigate their diverse backgrounds. This season continues to explore themes of friendship, identity, and community, all while delivering the signature wit and charm that fans have come to love.', 18.99, 13.49, 'DVD', 'instock', 1, 1, '1748422086.jpg', '1748422086-1.jpg', 12, 7, '', '', '0', '', '', '2025-05-28 03:18:06', '2025-05-28 03:18:06'),
(28, 'ACKLEY BRIDGE SERIES 5', '0', '0', 'ackley-bridge-series-5', 'Ackley Bridge: Series 5 features eight episodes that blend humor and drama in a multicultural school setting, focusing on the evolving lives of students and staff as they navigate personal and cultural challenges.', 'Ackley Bridge: Series 5 brings back the dynamic characters for another captivating season filled with humor, drama, and heartfelt moments. Set in a school that aims to unite diverse communities, this series explores the complexities of teenage life, friendships, and cultural identity. With eight episodes, viewers can expect a mix of laughter and poignant storytelling as the characters face new challenges and adventures.', 18.99, 14.99, 'DVD', 'instock', 1, 1, '1748422198.jpg', '1748422198-1.jpg', 12, 7, '', '', '0', '', '', '2025-05-28 03:19:58', '2025-05-28 03:19:58'),
(29, 'Unforgotten - Series 5', '0', '0', 'unforgotten-series-5', '\"Unforgotten: The Complete Fifth Season\" follows detectives Cassie and Sunny as they confront a chilling cold case, uncovering buried secrets that impact their lives and the lives of the victims\' families.', 'In \"Unforgotten: The Complete Fifth Season,\" detectives Cassie and Sunny delve into a haunting cold case that resurfaces, revealing deep-seated secrets and connections that challenge their understanding of justice. As they navigate the emotional landscape of the victims\' families and their own lives, the series explores themes of memory, loss, and the quest for truth, all while maintaining its signature blend of suspense and character-driven storytelling.', 15.45, 14.45, 'DVD', 'outofstock', 1, 1, '1748579495.jpg', '1748579397-1.jpeg', 10, 6, '', '', '0', '', '', '2025-05-29 22:59:58', '2025-07-25 22:51:37'),
(30, 'Unforgotten: Series 6', '0', '0', 'unforgotten-series-6', '\"Unforgotten: Series 6\" sees detectives Cassie and Sunny unravel a haunting cold case linked to a dismembered body, exposing hidden truths and the emotional struggles of those involved.', 'In \"Unforgotten: Series 6,\" the narrative intensifies as the Bishop Street detectives delve into a complex cold case that reveals the intertwined lives of a disparate group of suspects. As they navigate the emotional turmoil of the victims\' families and confront their own pasts, the series masterfully explores themes of memory, justice, and the impact of unresolved trauma, all while maintaining its signature suspenseful storytelling.', 34.99, 32.99, 'DVD', 'instock', 0, 1, '1748579587.jpg', '1748579587-1.jpg', 10, 6, '', '', '0', '', '', '2025-05-29 23:03:07', '2025-07-25 22:52:12'),
(32, 'Planet Earth', '0', '0', 'planet-earth', '\"Planet Earth\" is a visually stunning documentary series that explores the wonders of nature and wildlife across the globe, narrated by David Attenborough, offering an unforgettable viewing experience.', '\"Planet Earth\" is an extraordinary 11-part BBC series that takes viewers on a breathtaking journey across the globe, exploring various ecosystems and the incredible wildlife that inhabits them. With a production budget of $25 million, each episode is meticulously crafted to highlight the struggles and triumphs of life in Earth\'s most extreme environments, all narrated by the iconic David Attenborough.', 8.84, 7.84, 'DVD', 'instock', 1, 1, '1748598004.jpg', '1748598004-1.jpeg', 13, 8, '', '', '0', '', '', '2025-05-30 04:10:05', '2025-07-25 22:52:28'),
(33, 'Planet Earth 2', '0', '0', 'planet-earth-2', '\"Planet Earth II\" is a visually stunning nature documentary series narrated by Sir David Attenborough, exploring diverse habitats and the wildlife that inhabits them. It showcases the challenges animals face in their environments, utilizing advanced filming techniques to deliver breathtaking imagery.', '\"Planet Earth II\" is a groundbreaking nature documentary series that serves as a sequel to the original \"Planet Earth.\" Narrated by Sir David Attenborough, this series takes viewers on an extraordinary journey across the globe, showcasing the incredible diversity of life in various habitats. Each episode focuses on a different environment, including islands, mountains, jungles, deserts, and cities, highlighting the unique challenges faced by wildlife in these settings. The series employs cutting-edge filming techniques, including drone technology and ultra-high-definition cameras, to capture stunning visuals and intimate animal behaviors, making it a visual feast for nature lovers.', 19.99, 17.99, 'DVD', 'instock', 1, 1, '1748598475.jpg', '1748598475-1.jpeg', 13, 8, '', '', '0', '', '', '2025-05-30 04:17:58', '2025-07-25 22:52:42'),
(34, 'Planet Earth 3', '0', '0', 'planet-earth-3', '\"Planet Earth III\" is a visually captivating nature documentary series narrated by Sir David Attenborough, focusing on the planet\'s diverse ecosystems and the remarkable wildlife that inhabits them, highlighting the urgent need for conservation.', '\"Planet Earth III\" completes the celebrated trilogy, offering an in-depth exploration of Earth\'s most extraordinary ecosystems. Narrated by the iconic Sir David Attenborough, this series delves into the intricate relationships between wildlife and their environments. Each episode presents a different habitat, from lush rainforests to arid deserts, showcasing the challenges faced by various species in a rapidly changing world. The series utilizes state-of-the-art filming techniques, including 4K resolution and innovative camera technology, to provide viewers with an immersive experience that captures the beauty and fragility of nature.', 19.69, 17.69, 'DVD', 'instock', 1, 1, '1748598574.jpg', '1748598574-1.jpeg', 13, 8, '', '', '0', '', '', '2025-05-30 04:19:34', '2025-07-25 22:52:57'),
(35, 'Venom (Tom Hardy)', '0', '0', 'venom-tom-hardy', '\"Venom\" features Eddie Brock (Tom Hardy), who becomes the host for the alien symbiote Venom, leading to a chaotic and darkly humorous journey as he grapples with his new powers.', 'In \"Venom,\" Eddie Brock, a journalist, merges with an alien symbiote that grants him extraordinary abilities but also a violent alter ego. As he navigates his new identity, he faces challenges from both the symbiote and those who seek to exploit its power. The film blends action, dark comedy, and science fiction, showcasing Tom Hardy\'s compelling performance.', 14.99, 12.99, 'The Tom Hardy film', 'instock', 1, 1, '1748858069.jpg', '1748858069-1.jpeg', 14, 9, '', '', '0', '', '', '2025-06-02 04:24:30', '2025-07-25 22:53:12'),
(36, 'Venom (Let There Be Carnage)', '0', '0', 'venom-let-there-be-carnage', 'Venom: Let There Be Carnage\" features Eddie Brock, who struggles to coexist with the alien symbiote Venom while facing off against the deranged serial killer Cletus Kasady, who becomes the host for Carnage.', 'In this sequel to the 2018 film \"Venom,\" Eddie Brock (Tom Hardy) attempts to revive his career by interviewing Cletus Kasady (Woody Harrelson), a serial killer who becomes the host for the symbiote Carnage. As chaos ensues, Eddie must navigate his complex relationship with Venom while confronting a formidable new foe. Directed by Andy Serkis, the film blends action, horror, and dark humor, showcasing the struggle between good and evil within its characters.', 10.08, 8.08, 'The Tom Hardy film', 'instock', 1, 1, '1748858323.jpg', '1748858323-1.jpeg', 14, 9, '', '', '0', '', '', '2025-06-02 04:28:43', '2025-07-25 22:53:30'),
(37, 'Venom (The Last Dance)', '0', '0', 'venom-the-last-dance', '\"Venom: The Last Dance\" sees Tom Hardy return as Eddie Brock, who must navigate a dangerous world while facing new threats and making difficult choices alongside the alien symbiote Venom.', 'In \"Venom: The Last Dance,\" the final installment of the trilogy, Eddie Brock (Tom Hardy) and Venom are on the run, hunted by forces from both their worlds. As the net closes in, they are forced into a devastating decision that will change their lives forever. The film explores themes of identity, loyalty, and sacrifice, blending action and dark humor while showcasing the complex relationship between Eddie and Venom.', 26.99, 24.99, 'The Tom Hardy film', 'instock', 1, 1, '1748860221.jpg', '1748860221-1.jpeg', 14, 9, '', '', '0', '', '', '2025-06-02 04:38:14', '2025-07-25 22:53:49'),
(38, 'Stephen King\'s (IT)', '0', '0', 'stephen-kings-it', 'Based on one of Stephen King\'s bestselling novels, this is a story told in flashbacks. In a small town, a group of children are terrorized in their youth by an evil force. Thirty years later, when they learn of a new series of child murders, they return to see if they can\'t stop it once and for all. Adults now, with success in diverse careers, they still must come to terms with their pasts and with the evil that stalks their New England home town, and their own fears and nightmares.', 'Based on one of Stephen King\'s bestselling novels, this is a story told in flashbacks. In a small town, a group of children are terrorized in their youth by an evil force. Thirty years later, when they learn of a new series of child murders, they return to see if they can\'t stop it once and for all. Adults now, with success in diverse careers, they still must come to terms with their pasts and with the evil that stalks their New England home town, and their own fears and nightmares.', 12.97, 10.97, 'Stephen King\'s (IT)', 'instock', 1, 1, '1748860138.jpg', '1748860138-1.jpeg', 15, 10, '', '', '0', '', '', '2025-06-02 04:58:22', '2025-07-25 22:54:25'),
(39, 'It Chapter Two', '0', '0', 'it-chapter-two', 'Because every 27 years evil revisits the town of Derry, Maine, “It Chapter Two” brings the characters—who’ve long since gone their separate ways—back together as adults, nearly three decades after the events of the first film.', 'Because every 27 years evil revisits the town of Derry, Maine, “It Chapter Two” brings the characters—who’ve long since gone their separate ways—back together as adults, nearly three decades after the events of the first film.\r\n\r\nBonus Content:\r\n\r\n- Finding the Deadlights\r\n- Commentary by Director Andy Muschietti\r\n- The Summers of IT: Chapter One, You\'ll Float Too\r\n- The Summers of IT: Chapter Two, IT Ends\r\n- Pennywise Lives Again!\r\n- This Meeting of the Losers Club Has Officially Begun', 7.95, 6.95, 'It Chapter Two', 'instock', 1, 1, '1748860654.jpg', '1748860654-1.jpeg', 15, 10, '', '', '0', '', '', '2025-06-02 05:07:34', '2025-07-25 22:57:01'),
(45, 'Problem Child', '0', '0', 'problem-child', '\"Problem Child: The Troublesome Trilogy\" features the hilarious misadventures of Junior, a young boy whose antics turn his adoptive parents\' lives upside down. This collection captures the chaos and humor that arise from his mischievous behavior.', 'The trilogy follows Junior, a boy with a knack for trouble, as he navigates life with his adoptive parents, who quickly discover that raising him is no ordinary task. Each film in the series presents a new set of outrageous scenarios, showcasing the challenges and joys of parenting a child who constantly defies expectations. The blend of slapstick comedy and heartfelt moments resonates with audiences of all ages, making it a beloved series that explores themes of family dynamics, acceptance, and the unpredictability of childhood.', 6.49, 5.49, 'Problem Child', 'instock', 1, 1, '1749012447.jpg', '1749012447-1.jpeg', 12, 11, '', '', '0', '', '', '2025-06-03 23:17:27', '2025-07-25 22:57:19'),
(46, 'Problem Child 2', '0', '0', 'problem-child-2', 'Problem Child 2 (1991) is the chaotic sequel to the 1990 dark comedy Problem Child. Junior Healy, the mischievous adopted son, continues his reign of terror as his family moves to a new town. This time, he teams up with another troublemaker, Trixie, while his father, Ben, tries to win over her mother. Packed with outrageous pranks and slapstick humor, the film is a wild ride of \'90s comedy.', 'After the events of the first film, Ben Healy (John Ritter) and his adoptive son, Junior (Michael Oliver), relocate to the small town of Mortville for a fresh start. However, Junior’s talent for causing mayhem quickly resurfaces.\r\n\r\nThings get complicated when Ben falls for Lawanda Dumore (Laraine Newman), a single mother whose daughter, Trixie (Ivyann Schwan), is just as devious as Junior. The two troublemakers join forces, turning the town upside down with their pranks—from sabotaging a beauty pageant to wreaking havoc at a carnival.\r\n\r\nMeanwhile, Ben must deal with a jealous rival suitor (Jack Warden) while trying to keep Junior’s antics under control. The film escalates in absurdity, featuring over-the-top gags, crude humor, and Junior’s signature devilish grin.\r\n\r\nWhile not as successful as the first film, Problem Child 2 remains a cult favorite for fans of outrageous \'90s comedies.', 11.95, 9.95, 'Problem Child 2', 'instock', 1, 1, '1749012834.jpg', '1749012834-1.jpg', 12, 11, '', '', '0', '', '', '2025-06-03 23:23:55', '2025-07-25 22:57:38'),
(47, 'Problem Child 3', '0', '0', 'problem-child-3', 'Problem Child 3: Junior in Love (1995) is a made-for-TV sequel that follows teenage Junior Healy as he falls for a girl at school while continuing his mischievous antics. Unlike the first two theatrical films, this installment leans into a tamer, more kid-friendly tone but retains Junior’s signature troublemaking charm.', 'In this third (and final) installment of the Problem Child series, Junior Healy (now played by Justin Chapman) is older but no less troublesome. After moving to a new town with his adoptive father, Ben (William Katt, replacing John Ritter), Junior develops a crush on a girl named Eve. However, his usual pranks and bad behavior get in the way of winning her over.\r\n\r\nThe film takes a softer approach than its predecessors, focusing on Junior’s attempts to reform (sort of) while still causing chaos at school and home. The humor is less dark and more in line with a typical \'90s family TV movie, with slapstick gags and a moral about growing up.\r\n\r\nOriginally airing on USA Network, Problem Child 3 lacks the edgy tone of the first two films and received mixed reactions from fans. However, it remains a nostalgic curiosity for those who grew up with the series.', 11.95, 10.95, 'Problem Child 3', 'instock', 1, 1, '1749013286.jpg', '1749013286-1.jpg', 12, 11, '', '', '0', '', '', '2025-06-03 23:31:26', '2025-07-25 22:57:53'),
(48, 'PROBLEM CHILD 1-3 Box Set (DVD)', '0', '0', 'problem-child-1-3-box-set-dvd', 'The Problem Child trilogy is a series of dark comedy films centered around Junior Healy, a mischievous and demonic orphan who wreaks havoc on his adoptive parents, Ben and Flo Healy. The films blend slapstick humor with outrageous scenarios, making them cult favorites for fans of offbeat \'90s comedies.', 'The Problem Child trilogy consists of three films:\r\n\r\n    Problem Child (1990) – Ben and Flo Healy adopt Junior, an orphan with a talent for causing chaos. Despite his sweet appearance, Junior’s antics escalate, driving his new parents to desperation.\r\n\r\n    Problem Child 2 (1991) – The Healys move to a new town, where Junior continues his mischief while Ben falls for a woman with an equally troublesome daughter.\r\n\r\n    Problem Child 3: Junior in Love (1995) (TV Movie) – Now a teenager, Junior falls for a girl at school while still causing mayhem.', 11.95, 9.95, 'PROBLEM CHILD 1-3 Box Set (DVD)', 'instock', 0, 1, '1749013562.jpg', '1749013562-1.jpg,1749013562-2.jpg,1749013562-3.jpeg', 12, 11, '', '', '0', '', '', '2025-06-03 23:36:03', '2025-07-25 22:56:38'),
(49, 'Harry Potter: Complete 8-Film Collection', '0', '0', 'harry-potter-complete-8-film-collection', 'This collection spans all eight films in the Harry Potter series, chronicling the journey of Harry Potter (Daniel Radcliffe), Ron Weasley (Rupert Grint), and Hermione Granger (Emma Watson) as they grow from first-year students into heroes fighting the dark wizard Lord Voldemort (Ralph Fiennes).', 'Harry Potter and the Sorcerer’s Stone (2001) – Harry discovers he’s a wizard and begins his education at Hogwarts.\r\n\r\n    Harry Potter and the Chamber of Secrets (2002) – A mysterious force petrifies students, and Harry uncovers the Chamber of Secrets.\r\n\r\n    Harry Potter and the Prisoner of Azkaban (2004) – Sirius Black escapes Azkaban, and Harry learns shocking truths about his past.\r\n\r\n    Harry Potter and the Goblet of Fire (2005) – Harry competes in the deadly Triwizard Tournament.\r\n\r\n    Harry Potter and the Order of the Phoenix (2007) – Dumbledore’s Army resists the Ministry’s denial of Voldemort’s return.\r\n\r\n    Harry Potter and the Half-Blood Prince (2009) – Harry learns about Horcruxes while Draco plots against Dumbledore.\r\n\r\n    Harry Potter and the Deathly Hallows – Part 1 (2010) – The trio hunts Horcruxes while evading Snatchers.\r\n\r\n    Harry Potter and the Deathly Hallows – Part 2 (2011) – The final battle at Hogwarts decides the fate of the wizarding world.', 50.90, 47.90, 'Harry Potter: Complete 8-Film Collection', 'instock', 1, 2, '1749014332.jpg', '1749014332-1.jpeg,1749014332-2.jpeg,1749014332-3.jpeg,1749014332-4.jpeg,1749014332-5.jpeg,1749014332-6.jpeg,1749014332-7.jpeg,1749014332-8.jpeg', 8, 9, '', '', '0', '', '', '2025-06-03 23:48:53', '2025-07-25 22:56:26'),
(50, 'Fantastic Beasts and Where to Find Them', '0', '0', 'fantastic-beasts-and-where-to-find-them', 'Fantastic Beasts and Where to Find Them (2016) is a fantasy adventure film set in J.K. Rowling\'s Wizarding World, serving as a prequel to Harry Potter. It follows magizoologist Newt Scamander (Eddie Redmayne) as he tracks down escaped magical creatures in 1920s New York, uncovering a dark threat along the way.', 'Directed by David Yates and written by J.K. Rowling, Fantastic Beasts and Where to Find Them expands the Harry Potter universe into 1920s America. The story centers on Newt Scamander (Eddie Redmayne), a British magizoologist who arrives in New York with a suitcase full of magical creatures. When several escape, he teams up with No-Maj (Muggle) baker Jacob Kowalski (Dan Fogler), former Auror Tina Goldstein (Katherine Waterston), and her quirky sister Queenie (Alison Sudol) to recapture them.\r\n\r\nMeanwhile, a sinister force—an Obscurus—terrorizes the city, leading to tensions between the wizarding community and the Magical Congress of the United States (MACUSA). The film blends whimsical creature encounters with darker themes, setting up the conflict for future sequels.', 7.99, 6.99, 'Fantastic Beasts and Where to Find Them', 'instock', 1, 1, '1749016817.jpg', '1749016817-1.jpeg', 8, 9, '', '', '0', '', '', '2025-06-04 00:30:17', '2025-07-25 22:56:09'),
(51, 'Fantastic Beasts: The Crimes of Grindelwald', '0', '0', 'fantastic-beasts-the-crimes-of-grindelwald', 'Fantastic Beasts: The Crimes of Grindelwald (2018) is the second installment in J.K. Rowling’s Fantastic Beasts series. The dark fantasy sequel follows Newt Scamander (Eddie Redmayne) as he’s drawn into Gellert Grindelwald’s (Johnny Depp) plot to dominate the wizarding world, while secrets about Credence Barebone (Ezra Miller) and Albus Dumbledore (Jude Law) unravel.', 'Set in 1927, The Crimes of Grindelwald deepens the conflict between dark wizard Gellert Grindelwald (Johnny Depp) and a young Albus Dumbledore (Jude Law), who recruits Newt Scamander (Eddie Redmayne) to thwart Grindelwald’s rising army.\r\nKey Plot Points:\r\n\r\n    Grindelwald’s Escape: After breaking out of MACUSA custody, he rallies followers in Paris, promising wizard supremacy over Muggles.\r\n\r\n    Credence’s Mystery: The troubled Obscurial (Ezra Miller) searches for his true identity, with Grindelwald manipulating him.\r\n\r\n    Newt’s Mission: Reluctantly working with Dumbledore, Newt reunites with Tina, Queenie, and Jacob—but alliances fracture as Queenie falls under Grindelwald’s influence.\r\n\r\n    Shocking Revelations: The film unveils ties to Harry Potter lore (e.g., Nagini’s origin, Dumbledore’s past with Grindelwald).', 8.99, 7.99, 'Fantastic Beasts: The Crimes of Grindelwald', 'instock', 1, 1, '1749018274.jpg', '1749018274-1.jpeg', 8, 9, '', '', '0', '', '', '2025-06-04 00:54:35', '2025-07-25 22:55:55'),
(52, 'Fantastic Beasts: The Secrets of Dumbledore', '0', '0', 'fantastic-beasts-the-secrets-of-dumbledore', 'Fantastic Beasts: The Secrets of Dumbledore (2022) is the third installment in the Fantastic Beasts series. The film follows Albus Dumbledore (Jude Law) and Newt Scamander (Eddie Redmayne) as they lead a mission to stop Gellert Grindelwald (Mads Mikkelsen) from seizing control of the wizarding world. Packed with magical battles, political intrigue, and emotional revelations, this chapter delves deeper into Dumbledore’s past and his complex relationship with Grindelwald.', 'Set in the 1930s, The Secrets of Dumbledore centers on Dumbledore’s secret plan to thwart Grindelwald’s rise to power. With Grindelwald manipulating elections to become the Supreme Leader of the wizarding world, Dumbledore assembles a team—including Newt Scamander, his brother Theseus, Jacob Kowalski, and Lally Hicks—to disrupt his plans.\r\n\r\nKey storylines include:\r\n\r\n    The Blood Pact: Dumbledore and Grindelwald’s magical bond prevents them from fighting directly, forcing Dumbledore to work through others.\r\n\r\n    Credence’s Fate: The tortured Obscurial (Ezra Miller) learns his true identity as Aurelius Dumbledore, adding emotional weight to the conflict.\r\n\r\n    The Qilin Prophecy: Grindelwald exploits a mystical creature’s power to sway the wizarding government, leading to a dramatic showdown.', 9.99, 7.99, 'Fantastic Beasts: The Secrets of Dumbledore', 'instock', 1, 1, '1749018421.jpg', '1749018421-1.jpeg', 8, 9, '', '', '0', '', '', '2025-06-04 00:57:02', '2025-07-25 22:55:39'),
(53, 'Gladiator (2000)', '0', '0', 'gladiator-2000', 'Starring Russell Crowe, Gladiator is an epic historical drama directed by Ridley Scott. Crowe plays Maximus Decimus Meridius, a betrayed Roman general forced into slavery who rises as a gladiator to avenge his family and overthrow the corrupt Emperor Commodus (Joaquin Phoenix).** Winner of 5 Oscars, including Best Picture and Best Actor for Crowe, the film is renowned for its breathtaking action, emotional depth, and iconic quotes (\"Are you not entertained?\").', 'Plot Summary:\r\n\r\nSet in 180 AD, Gladiator follows Maximus (Russell Crowe), a loyal general to Emperor Marcus Aurelius (Richard Harris). When Aurelius is murdered by his power-hungry son Commodus (Joaquin Phoenix), Maximus is betrayed, his family slaughtered, and he is sold into slavery. After enduring brutal gladiatorial combat, he rises through the ranks, seeking vengeance against Commodus while inspiring the oppressed Roman people.\r\nKey Themes & Highlights:\r\n\r\n    Revenge & Redemption: Maximus’ journey from general to slave to legend.\r\n\r\n    Political Intrigue: Commodus’ tyrannical rule and the Senate’s resistance.\r\n\r\n    Epic Battles: The Colosseum fights are visceral and groundbreaking (Oscar-winning VFX).\r\n\r\n    Emotional Score: Hans Zimmer’s \"Now We Are Free\" remains iconic.\r\n\r\nCast & Legacy:\r\n\r\n    Russell Crowe (Oscar-winning performance)\r\n\r\n    Joaquin Phoenix (Oscar-nominated as the villainous Commodus)\r\n\r\n    Connie Nielsen, Oliver Reed, Djimon Hounsou\r\n\r\n    Cultural Impact: Revived the sword-and-sandals genre; spawned memes and homages.', 7.99, 5.99, 'Gladiator (2000)', 'instock', 0, 1, '1749023362.jpg', '1749023362-1.jpeg', 16, 12, '', '', '0', '', '', '2025-06-04 02:18:36', '2025-07-25 22:55:24'),
(54, 'Gladiator II (2024)', '3rd March 2025', '2', 'gladiator-ii-2024', '\"Gladiator II\" (2024) is the long-awaited sequel to Ridley Scott’s 2000 epic Gladiator, starring Paul Mescal as Lucius, the grown-up nephew of Joaquin Phoenix’s Commodus. Russell Crowe returns in a surprise role (via flashbacks or visions) alongside new stars Pedro Pascal, Denzel Washington, and Joseph Quinn. Set decades after the original, the film follows Lucius’ journey from noble heir to gladiator, battling corruption in a decaying Roman Empire.', 'Plot & Setting:\r\n\r\n    Time Jump: Set 20-30 years after Maximus’ death, Rome is under new tyranny.\r\n\r\n    Lucius’ Arc: Now an adult (Paul Mescal), he’s forced into slavery and becomes a gladiator, mirroring Maximus’ path.\r\n\r\n    New Villains: Joseph Quinn (Emperor Geta) and Fred Hechinger (co-emperor Caracalla) rule ruthlessly.\r\n\r\n    Denzel Washington: Plays a wealthy arms dealer with gladiator ties.\r\n\r\n    Pedro Pascal: A rival gladiator turned ally.\r\n\r\nRussell Crowe’s Role:\r\n\r\nThough Maximus died in Gladiator, Crowe appears in dream sequences or afterlife visions, tying the two films thematically.\r\nDirector & Expectations:\r\n\r\n    Ridley Scott returns, promising bigger battles, political intrigue, and emotional stakes.\r\n\r\n    Early footage teased naval combat in the Colosseum and a gorgeous Roman Empire aesthetic.', 14.99, 10.99, 'DVD', 'instock', 0, 1, '1749023513.jpg', '1749023513-1.jpeg', 23, 12, '5056453207782', '5056453207782', 'English-United States, French-Parisian, Hard of Hearing Subtitles: English-United States, Subtitles: English-United States, Danish, Dutch, Finnish, French-Parisian, Norwegian, Swedish, Interactive Menu, Screen ratio 1 - 2.39:1, Dolby Digital 5.1', '142 minutes', 'barcodes/1757051438_barcode.png', '2025-06-04 02:21:53', '2025-09-05 00:20:38');
INSERT INTO `products` (`id`, `name`, `released_date`, `region_code`, `slug`, `short_description`, `description`, `regular_price`, `sale_price`, `SKU`, `stock_status`, `featured`, `quantity`, `image`, `images`, `category_id`, `brand_id`, `productcode`, `barcode`, `language`, `duration`, `barcode_img`, `created_at`, `updated_at`) VALUES
(55, '\"Smile\" (Once You See It, It\'s Too Late)', '26th December 2022', '0', 'smile-once-you-see-it-its-too-late', '\"Smile\" (Once You See It, It\'s Too Late) is a supernatural psychological horror film about a cursed chain of trauma. When psychiatrist Dr. Rose Cotter (Sosie Bacon) witnesses a patient\'s gruesome suicide—marked by a terrifying, unnatural grin—she becomes the next target of a demonic entity that spreads like a virus through witnessed trauma. The more Rose fights it, the more it consumes her sanity, leading to a shocking climax.', 'Plot & Themes:\r\n\r\nAfter her patient Laura (Caitlin Stasey) dies by suicide while smiling with inhumanly stretched lips, Dr. Rose Cotter begins seeing the same eerie grins on strangers, loved ones, and eventually herself. The entity mimics people she knows, warping reality to isolate and torment her.\r\n\r\n    The Curse: The entity passes from victim to victim like a supernatural parasite, feeding on trauma.\r\n\r\n    Descent into Madness: Rose’s investigations lead her to a previous survivor (Robin Weigert), revealing the curse’s cyclical nature.\r\n\r\n    Final Twist: A brutal, nihilistic ending subverts typical horror resolutions.\r\n\r\nStyle & Influences:\r\n\r\n    Unsettling Visuals: The \"smile\" effect is grotesque yet subtle.\r\n\r\n    Psychological Horror: Comparable to It Follows and The Ring, but with a focus on mental health metaphors.\r\n\r\n    Sound Design: Distorted voices and sudden silences amplify dread.\r\n\r\nReception:\r\n\r\n    Box Office Sleeper Hit: Made $217M+ on a $17M budget.\r\n\r\n    Critics: Praised for tension and Sosie Bacon’s performance, though some called it derivative.', 9.99, 6.99, 'Blu-ray', 'instock', 0, 1, '1749024115.jpg', '1749024115-1.jpeg', 19, 10, '5056453204279', '5056453204279', 'English, French-Canadian, French-Parisian, German, Italian, Japanese, Spanish-Castilian, Spanish-Latin American, Hard of Hearing Subtitles: English, Subtitles: English, Chinese-Mandarian, Chinese-Traditional, Chinese-Taiwan & Singapore, Danish, Dutch, Finnish, French-Canadian, French-Parisian, German, Italian, Japanese, Norwegian, Spanish-Castilian, Spanish-Latin American, Swedish, Turkish, Interactive Menu, Screen ratio 1 - 2.00:1, Dolby Atmos, Dolby Digital 5.1, Bonus Footage, Commentary: Parker Finn (director/writer), Deleted Scenes, Documentaries: \'Something\'s Wrong With Rose\'; \'Flies On the Wall: Inside the Score\', Making of Documentary, Short film with introduction by Parker Finn: \'Laura Hasn\'t Slept\'', '116 minutes', 'barcodes/1757051892_barcode.png', '2025-06-04 02:31:55', '2025-09-05 00:28:12'),
(56, 'Smile 2', '20th January 2025', '0', 'smile-2', '\"Smile 2\" (Once You See It, It\'s Too Late) is the terrifying sequel to the 2022 horror hit. This installment follows a new protagonist, pop star Skye Riley (Naomi Scott), as she becomes the latest target of the demonic entity that spreads through traumatic encounters. After witnessing a shocking death during her concert tour, Skye begins seeing the same unnerving grins that haunted Dr. Rose Cotter - realizing too late that the curse has chosen her as its next victim.', 'Expanded Plot & New Direction:\r\n\r\nThe sequel shifts focus to international pop sensation Skye Riley, whose life turns into a nightmare when:\r\n\r\n    A crew member dies by suicide mid-concert with that signature smile\r\n\r\n    The entity begins appearing in mirrors, audiences, and even on camera feeds\r\n\r\n    Her team thinks she\'s having a mental breakdown as she tries to expose the truth\r\n\r\n    The curse evolves with new rules - now spreading through recorded footage of traumatic events\r\n\r\nKey Enhancements from the Original:\r\n\r\n    Bigger Scope: Moves beyond individual trauma to explore viral horror in the digital age\r\n\r\n    New Manifestations: The smile now appears in social media posts and live broadcasts\r\n\r\n    Music Integration: Skye\'s performances become increasingly disturbing as the entity takes over\r\n\r\n    Deeper Mythology: Reveals more about the entity\'s origins while maintaining mystery\r\n\r\nRelease & Reception:\r\n\r\n    Theatrical Release: October 18, 2024 (just in time for Halloween)\r\n\r\n    Early Buzz: Praised for fresh take on the concept while maintaining the original\'s tension\r\n\r\n    Director: Parker Finn returns with a more ambitious vision', 14.99, 24.99, '4K UHD BLU-RAY', 'instock', 0, 1, '1749024267.jpg', '1749024267-1.jpeg', 18, 10, '5056453207751', '5056453207751', 'Engish, French, Canadian, Persian, German, Italian,Japanise, Polish, Spanish', '160 mintues', 'barcodes/1756898526_barcode.png', '2025-06-04 02:34:28', '2025-09-03 05:52:06'),
(57, 'Joker (2019)', '10th February 2020', '2', 'joker-2019', '\"Joker\" is a psychological crime thriller starring Joaquin Phoenix as Arthur Fleck, a mentally ill failed comedian whose descent into madness transforms him into the iconic DC villain. Set in 1981 Gotham City, the film explores themes of societal neglect, mental health, and violent rebellion, offering a dark origin story separate from traditional superhero narratives. Winner of 2 Oscars (Best Actor, Best Score)', 'Plot & Themes:\r\n\r\n    Arthur Fleck: A clown-for-hire with neurological laughter disorder struggles with poverty and isolation.\r\n\r\n    Breaking Point: After being mocked, fired, and denied medication, Arthur commits a subway shooting that sparks citywide unrest.\r\n\r\n    Twist: His idol, talk-show host Murray Franklin (Robert De Niro), becomes a target of his rage.\r\n\r\n    Ambiguity: The film questions whether Arthur’s transformation is real or a delusion.\r\n\r\nKey Elements:\r\n\r\n    Style: Homages to Scorsese’s Taxi Driver and The King of Comedy with gritty 1970s aesthetic.\r\n\r\n    Performance: Phoenix’s physical transformation (losing 52 lbs) and haunting laugh became iconic.\r\n\r\n    Controversy: Debates about its portrayal of violence and mental illness.\r\n\r\nAwards & Legacy:\r\n\r\n    First R-rated film to earn $1 billion.\r\n\r\n    Oscars: Best Actor (Phoenix), Best Original Score (Hildur Guðnadóttir’s cello-driven soundtrack).', 9.99, 7.99, 'DVD', 'outofstock', 0, 3, '1749025009.jpg', '1749025220-1.jpeg', 18, 14, '5051892225571', '5051892225571', 'English, Castilian Spanish, Hard of Hearing Subtitles: English, Subtitles: English, Castilian Spanish, Danish, Finnish, Greek, Norwegian, Swedish, Interactive Menu, Screen ratio 1 - 1.85:1, Dolby Digital 5.1, Documentaries: \'Please Welcome... Joker!\'', '117 minutes', 'barcodes/1756898013_barcode.png', '2025-06-04 02:46:50', '2025-09-03 05:43:33'),
(63, 'test product', '5/9/2025', '2', 'test-product', 'test description', 'test description', 12.00, 10.00, 'DVD', 'outofstock', 0, 0, '1756879156.jpg', '1756879156-1.jpeg,1756879156-2.jpeg', 14, 9, '5051892225588', '5051892225588', 'English', '160 mintues', 'barcodes/1756884262_barcode.png', '2025-09-03 00:29:16', '2025-09-03 01:54:22'),
(64, 'Product 1', '5/9/2025', '2', 'product-12', 'test', 'test', 12.00, 10.00, 'DVD', 'outofstock', 0, 200, '1756879534.jpg', '1756879534-1.jpeg', 14, 9, '5051892225588', '5051892225588', 'English', '160 mintues', 'barcodes/1756879534_barcode.png', '2025-09-03 00:35:34', '2025-09-03 00:35:34');

-- --------------------------------------------------------

--
-- Table structure for table `quiries`
--

CREATE TABLE `quiries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `ordernumber` varchar(255) NOT NULL,
  `inquiry` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `stars` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `product_id`, `name`, `email`, `stars`, `created_at`, `updated_at`) VALUES
(1, '', 'Raman 😏', 'ramanpreetsingh251@gmail.com', 4, '2025-09-12 04:37:17', '2025-09-12 04:37:17'),
(11, '15', 'gurpreet kaur', 'manpreet200200singh@gmail.com', 4, '2025-10-16 05:55:01', '2025-10-16 05:55:01'),
(12, '64', 'RAMAN', 'manpreet200200singh@gmail.com', 3, '2025-10-16 22:38:42', '2025-10-16 22:38:42'),
(13, '12', 'gurpreet kaur', 'manpreet200200singh@gmail.com', 4, '2025-10-22 23:00:26', '2025-10-22 23:00:26'),
(14, '64', 'RAMAN', 'ramanpreetsingh251@gmail.com', 2, '2025-10-31 00:24:49', '2025-10-31 00:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('RfeMVISvcSap3kmYtLV06oMVuNINNU27uq6qx9Eh', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoibFI3WU4zRm5YWmgwQkg4SXhWOWxiMkdQSHlIUjJhVmdFUENmQk5kUSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC93aXNobGlzdCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzYxODk0MzY1O31zOjQ6ImNhcnQiO2E6Mjp7czo0OiJjYXJ0IjtPOjI5OiJJbGx1bWluYXRlXFN1cHBvcnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YToyOntzOjMyOiIzMDc0ZTJmZjQ0ZGQ3N2ZkMmZlYjljMzA2N2M1MjJhMCI7TzozNToiU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0iOjk6e3M6NToicm93SWQiO3M6MzI6IjMwNzRlMmZmNDRkZDc3ZmQyZmViOWMzMDY3YzUyMmEwIjtzOjI6ImlkIjtzOjI6IjU3IjtzOjM6InF0eSI7czoxOiIxIjtzOjQ6Im5hbWUiO3M6MTI6Ikpva2VyICgyMDE5KSI7czo1OiJwcmljZSI7ZDo3Ljk5O3M6Nzoib3B0aW9ucyI7Tzo0MjoiU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NTI6IgBTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0NDoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0NDoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9czozMjoiODhhYWQ2NWExNDE2YzgyNzFjZGRjMmVlNDhlNGEzMGIiO086MzU6IlN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiI4OGFhZDY1YTE0MTZjODI3MWNkZGMyZWU0OGU0YTMwYiI7czoyOiJpZCI7czoyOiI1NiI7czozOiJxdHkiO3M6MToiMSI7czo0OiJuYW1lIjtzOjc6IlNtaWxlIDIiO3M6NToicHJpY2UiO2Q6MjQuOTk7czo3OiJvcHRpb25zIjtPOjQyOiJTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbU9wdGlvbnMiOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo1MjoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGFzc29jaWF0ZWRNb2RlbCI7czoxODoiQXBwXE1vZGVsc1xQcm9kdWN0IjtzOjQ0OiIAU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AdGF4UmF0ZSI7aToyMTtzOjQ0OiIAU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AaXNTYXZlZCI7YjowO319czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjg6Indpc2hsaXN0IjtPOjI5OiJJbGx1bWluYXRlXFN1cHBvcnRcQ29sbGVjdGlvbiI6Mjp7czo4OiIAKgBpdGVtcyI7YTozOntzOjMyOiJlZWQ5MmM3ZmM3MTc4MjMwMmQ3Mjc2ZGNjZmZhMTU5NyI7TzozNToiU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0iOjk6e3M6NToicm93SWQiO3M6MzI6ImVlZDkyYzdmYzcxNzgyMzAyZDcyNzZkY2NmZmExNTk3IjtzOjI6ImlkIjtzOjI6IjY0IjtzOjM6InF0eSI7czoxOiIxIjtzOjQ6Im5hbWUiO3M6OToiUHJvZHVjdCAxIjtzOjU6InByaWNlIjtkOjEwO3M6Nzoib3B0aW9ucyI7Tzo0MjoiU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW1PcHRpb25zIjoyOntzOjg6IgAqAGl0ZW1zIjthOjA6e31zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fXM6NTI6IgBTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBhc3NvY2lhdGVkTW9kZWwiO3M6MTg6IkFwcFxNb2RlbHNcUHJvZHVjdCI7czo0NDoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAHRheFJhdGUiO2k6MjE7czo0NDoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGlzU2F2ZWQiO2I6MDt9czozMjoiMDJkZGJjMzQ3ZDc4NWY1YzQ3YmNiZTgxOTJlYTMwYzMiO086MzU6IlN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtIjo5OntzOjU6InJvd0lkIjtzOjMyOiIwMmRkYmMzNDdkNzg1ZjVjNDdiY2JlODE5MmVhMzBjMyI7czoyOiJpZCI7czoyOiI1NSI7czozOiJxdHkiO3M6MToiMSI7czo0OiJuYW1lIjtzOjQwOiIiU21pbGUiIChPbmNlIFlvdSBTZWUgSXQsIEl0J3MgVG9vIExhdGUpIjtzOjU6InByaWNlIjtkOjYuOTk7czo3OiJvcHRpb25zIjtPOjQyOiJTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbU9wdGlvbnMiOjI6e3M6ODoiACoAaXRlbXMiO2E6MDp7fXM6Mjg6IgAqAGVzY2FwZVdoZW5DYXN0aW5nVG9TdHJpbmciO2I6MDt9czo1MjoiAFN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtAGFzc29jaWF0ZWRNb2RlbCI7czoxODoiQXBwXE1vZGVsc1xQcm9kdWN0IjtzOjQ0OiIAU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AdGF4UmF0ZSI7aToyMTtzOjQ0OiIAU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AaXNTYXZlZCI7YjowO31zOjMyOiI4OGFhZDY1YTE0MTZjODI3MWNkZGMyZWU0OGU0YTMwYiI7TzozNToiU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0iOjk6e3M6NToicm93SWQiO3M6MzI6Ijg4YWFkNjVhMTQxNmM4MjcxY2RkYzJlZTQ4ZTRhMzBiIjtzOjI6ImlkIjtzOjI6IjU2IjtzOjM6InF0eSI7czoxOiIxIjtzOjQ6Im5hbWUiO3M6NzoiU21pbGUgMiI7czo1OiJwcmljZSI7ZDoyNC45OTtzOjc6Im9wdGlvbnMiO086NDI6IlN1cmZzaWRlbWVkaWFcU2hvcHBpbmdjYXJ0XENhcnRJdGVtT3B0aW9ucyI6Mjp7czo4OiIAKgBpdGVtcyI7YTowOnt9czoyODoiACoAZXNjYXBlV2hlbkNhc3RpbmdUb1N0cmluZyI7YjowO31zOjUyOiIAU3VyZnNpZGVtZWRpYVxTaG9wcGluZ2NhcnRcQ2FydEl0ZW0AYXNzb2NpYXRlZE1vZGVsIjtzOjE4OiJBcHBcTW9kZWxzXFByb2R1Y3QiO3M6NDQ6IgBTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbQB0YXhSYXRlIjtpOjIxO3M6NDQ6IgBTdXJmc2lkZW1lZGlhXFNob3BwaW5nY2FydFxDYXJ0SXRlbQBpc1NhdmVkIjtiOjA7fX1zOjI4OiIAKgBlc2NhcGVXaGVuQ2FzdGluZ1RvU3RyaW5nIjtiOjA7fX19', 1761908904);

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE `slides` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`id`, `tagline`, `title`, `subtitle`, `link`, `image`, `status`, `created_at`, `updated_at`) VALUES
(7, 'tagline', 'movies', 'title', 'http://rivona.co.uk/', '1748252889.jpg', '1', '2025-05-23 05:31:37', '2025-05-26 04:18:10'),
(8, 'Paddington 2', 'Paddington 2', 'Paddington 2', 'http://rivona.co.uk/', '1748252871.jpg', '1', '2025-05-23 05:33:55', '2025-05-26 04:17:54'),
(9, 'Beauty and', 'the Beast', 'Adventure', 'http://rivona.co.uk/', '1748334299.jpg', '1', '2025-05-27 02:55:02', '2025-05-27 02:55:02'),
(10, 'Beauty and', 'Avengers End Game', 'Adventure', 'http://rivona.co.uk/', '1760761858.jpg', '1', '2025-10-17 23:01:00', '2025-10-17 23:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `mode` enum('cod','card','paypal') NOT NULL,
  `status` enum('pending','approved','declined','refunded') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `order_id`, `mode`, `status`, `created_at`, `updated_at`) VALUES
(13, 3, 22, 'cod', 'approved', '2025-10-10 23:26:24', '2025-10-10 23:26:24'),
(14, 5, 23, 'cod', 'approved', '2025-10-10 23:29:52', '2025-10-10 23:29:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `utype` varchar(255) NOT NULL DEFAULT 'USR' COMMENT 'ADM for Admin and USR for User or Customer',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `utype`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'admin', 'admin@gmail.com', NULL, '$2y$12$V8x7Ql6gHiJfgpzhlulSZOepfphiFEgmUaKAXd6y7YzsosMKocDS6', 'ADM', 'V5BtkedCorEe3sPfYcX8DaHsHrJBIeU0gOlk9epQJNBZE55Fcns9gYJ0Z4fj', '2025-05-26 04:15:12', '2025-05-26 04:15:12'),
(4, 'user', 'user@gmail.com', NULL, '$2y$12$BDcKvrkYAkxwuVVmwHY2T.tNJksheHqNq0BOdMPiGSr8l0GL8Vmqe', 'USR', NULL, '2025-05-26 04:16:01', '2025-05-26 04:16:01'),
(5, 'User', 'manpreet200200singh@gmail.com', NULL, '$2y$12$miSidSmCS4Qo5kKbsdrJDemdISC2ZwiLW/nUveiyJnUX6i2PVAun2', 'USR', 'i75ROItpQoh0JwCMrpsxl14yDaVBytV6KJrF2MMpJVotYD2GHDZOPDqk0obB', '2025-06-24 05:21:41', '2025-06-24 05:21:41'),
(6, 'Raman', 'weblearning@ramantech.site', NULL, '$2y$12$9aO0BC4LwyGDRgXp4au8AeUyzn.i8Vw8SEPfhoeUE0KUVXFfEjb3.', 'USR', NULL, '2025-06-25 04:24:11', '2025-06-25 04:24:11'),
(7, 'gurpreet kaur', 'example@gmail.com', NULL, '$2y$12$EJiWyVGg7PGIcJkhGfaD7u0fK3zAw.e7OMPS.vpcL9qL40duSUO/.', 'USR', NULL, '2025-06-25 04:29:25', '2025-06-25 04:29:25');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 3, 64, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about2s`
--
ALTER TABLE `about2s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_user_id_foreign` (`user_id`);

--
-- Indexes for table `blacks`
--
ALTER TABLE `blacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `brands_slug_unique` (`slug`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `month_names`
--
ALTER TABLE `month_names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  ADD KEY `personal_access_tokens_expires_at_index` (`expires_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`);

--
-- Indexes for table `quiries`
--
ALTER TABLE `quiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `slides`
--
ALTER TABLE `slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_user_id_foreign` (`user_id`),
  ADD KEY `transactions_order_id_foreign` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about2s`
--
ALTER TABLE `about2s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `blacks`
--
ALTER TABLE `blacks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `month_names`
--
ALTER TABLE `month_names`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `quiries`
--
ALTER TABLE `quiries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `slides`
--
ALTER TABLE `slides`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
