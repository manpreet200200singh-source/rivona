@extends('layouts.app')
@section('content')
    <style>
        p {
            font-size: 18px;
            font-weight: 300;
        }
        h4 {
            font-weight: 600;
        }
    </style>

    <h1 class="text-center">_Privacy Policy_</h1>
    <div class="container">
        <div class="row">
            <div class="col-12 text-justify">
                <h4>Thanks for visiting the website of Rivona.co.uk</h4>
                <p>We collect no personal information, such as names or addresses, when you visit our website. If you choose to provide that information to us, it is only used to fulfill your request for information.</p>

                <p>We do collect some technical information when you visit to make your experience seamless. The section below explains how we handle and collect technical information when you visit our website.</p>

                <p>Information is collected and stored automatically when you browse, read pages, or download information on this website. We automatically gather and store certain technical information about your visit. This information never identifies who you are.</p>

                <h4>The information we collect and store about your visit is listed below:</h4>
                <p>
                    The Internet domain of your service provider (e.g. example.co.uk) and IP address (an IP address is a number that is automatically assigned to your computer whenever you’re surfing the web) from which you access our website.
                </p>
                <p>
                    The type of browser (such as Chrome, Firefox, or Safari) and operating system (Windows, macOS, Linux) used to access our site.
                </p>
                <p>
                    The date and time you accessed our site.
                </p>
                <p>
                    The pages/URLs you have visited and
                </p>
                <p>
                    If you reached this website from another website, the address of that referring website.
                </p>
                <p>
                    This information is only used to help us make the site more useful for you. With this data, we learn about the number of visitors to our site and the types of technology our visitors use. We never track or record information about individuals and their visits.
                </p>

                <h4>Cookies</h4>
                <p>
                    When you visit some websites, they may download small pieces of software on your computer/browsing device known as cookies. Some cookies collect personal information to recognize your computer in the future. We only use non-persistent cookies or “per-session cookies”.
                </p>
                <p>
                    Per-session cookies serve technical purposes, like providing seamless navigation through this website. These cookies do not collect personal information on users and they are deleted as soon as you leave our website. The cookies do not permanently record data and are not stored on your computer’s hard drive. The cookies are stored in memory and are only available during an active browser session. Again, once you close your browser, the cookie disappears.
                </p>
                <p>
                    If you send us personal information
                </p>
                <p>
                    We do not collect personal information for any purpose other than to respond to you (for example, to respond to your questions or provide information you have asked). If you choose to provide us with personal information—like filling out a Contact Us form, with an e-mail address or postal address, and submitting it to us through the website—we use that information to respond to your message and to help you get the information you’ve requested. We only share the information you give us with another agency if your question relates to that agency, or as otherwise required by law.
                </p>
                <p>
                    Our website never collects information or creates individual profiles for commercial marketing. While you must provide an e-mail address for a localized response to any incoming questions or comments to us, we recommend that you do NOT include any other personal information.
                </p>

                <h4>Site Security</h4>
                <p>
                    For site security purposes and to ensure that this service remains available to all users, this computer system employs commercial software programs to monitor network traffic to identify unauthorized attempts to upload or change information, or otherwise cause damage.
                </p>
                <p>
                    Except for authorized law enforcement investigations, no other attempts are made to identify individual users or their usage habits. Raw data logs are used for no other purposes and are scheduled for regular deletion.
                </p>
                <p>
                    Unauthorized attempts to upload information or change information on this service are strictly prohibited and may be punishable under UK law.
                </p>
                <p>
                    All the information gathered through this website is subject to the following conditions:
                </p>
                <p>
                    Rivona.co.uk may send you emails/SMS about our services, new offerings, happenings, and other updates.
                </p>
                <p>
                    Rivona.co.uk can call to provide you with important/necessary information or for follow-up.
                </p>
                <p>
                    We do not share your information (i.e., Contact Number, Email ID) with any third party and maintain its confidentiality.
                </p>
                <p>
                    Rivona.co.uk makes reasonable efforts to provide accurate information; however, it assumes no liability for any inaccuracies provided to you through non-official websites.
                </p>
                <p>
                    Rivona.co.uk reserves the right to make changes to the above-mentioned policy from time to time.
                </p>
                <h4>Terms</h4>
                <p>
                    Though all efforts have been made to ensure the accuracy and currency of the content on this website, the same should not be construed as a statement of law or used for any legal purposes. In case of any ambiguity or doubts, users are advised to verify/check with the organization and/or other sources, and to obtain appropriate professional advice.
                </p>
                <p>
                    Under no circumstances will this organization be liable for any expense, loss, or damage including, without limitation, indirect or consequential loss or damage, or any expense, loss, or damage whatsoever arising from use, or loss of use, of data, arising out of or in connection with the use of this website. These terms and conditions shall be governed by and construed in accordance with UK laws. Any dispute arising under these terms and conditions shall be subject to the jurisdiction of the courts of the UK.
                </p>
                <p>
                    The information posted on this website could include hypertext links or pointers to information created and maintained in private organizations. Rivona.co.uk is providing these links and pointers solely for your information and convenience. When you select a link to an outside website, you are leaving the Rivona.co.uk website and are subject to the privacy and security policies of the owners/sponsors of the outside website. Rivona.co.uk does not guarantee the availability of such linked pages at all times.
                </p>
                <p>
                    Rivona.co.uk cannot authorize the use of copyrighted materials contained in linked websites. Users are advised to request such authorization from the owner of the linked website. Rivona.co.uk does not guarantee that linked websites comply with UK Government Web Guidelines.
                </p>
            </div>
        </div>
    </div>
@endsection
