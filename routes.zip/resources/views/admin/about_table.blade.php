@extends('layouts.admin')
@section('content')

<h1>About Table</h1>

<div class="main-content-inner">
    <div class="main-content-wrap">
        <div class="flex items-center flex-wrap justify-between gap20 mb-27">
            <h3>Brands</h3>
            <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                <li>
                    <a href="{{ route('admin.index') }}">
                        <div class="text-tiny">Dashboard</div>
                    </a>
                </li>
                <li>
                    <i class="icon-chevron-right"></i>
                </li>
                <li>
                    <div class="text-tiny">About</div>
                </li>
            </ul>
        </div>

        <div class="wg-box">
            <div class="flex items-center justify-between gap10 flex-wrap">
                <div class="wg-filter flex-grow">
                    <form class="form-search">
                        <fieldset class="name">
                            <input type="text" placeholder="Search here..." class="" name="name"
                                tabindex="2" value="" aria-required="true" required="">
                        </fieldset>
                        <div class="button-submit">
                            <button class="" type="submit"><i class="icon-search"></i></button>
                        </div>
                    </form>
                </div>
                <a class="tf-button style-1 w208" href="{{ route('about_form') }}"><i
                        class="icon-plus"></i>Add new</a>
            </div>
            <div class="wg-table table-all-user">
                <div class="table-responsive">
                    @if(Session::has('status'))
                    <p class="alert alert-success">{{ Session::get('status') }}</p>
                    @endif
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Picture</th>
                                <th>Story</th>
                                <th>Mission</th>
                                <th>Vison</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach ($about as $a)
                            <tr>
                                <td>{{ $a->id }}</td>
                                <td class="pname">
                                    <div class="image">
                                        <img src="{{ asset('uploads/about/') }}/{{ $a->pic }}" alt="" class="image" >
                                        <!--public_html/rivona.co.uk/uploads/about-->
                                    </div>
                                </td>
                                <td>{{ $a->story }}</td>
                                <td>{{ $a->mission }}</td>
                                <td>{{ $a->vision }}</td>
                                <td>{{ $a->company }}</td>
                                {{-- <td><a href="" target="_blank">0</a></td> --}}
                                <td>
                                    <a href="{{ route('about_delete',['id'=>$a->id]) }}" class="btn btn-warning">Delete</a>
                                </td>
                                <td>
                                    <a href="{{ route('about_edit',['id'=>$a->id]) }}" class="btn btn-warning">Edit</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                </div>


            </div>
        </div>
    </div>
</div>


@endsection

