@extends('layouts.admin')
@section('content')
<style>
    .btn{
        height: 40px;
        width: 200px;
        color: white;
    }
   :hover.btn{

        border-radius: 10px;
        color: white;
        font-weight: 900;
    }
</style>
    <div class="pagetitle">
      <h1>All Messages</h1>
      <div class="table-responsive">
      <nav>
        <ol class="breadcrumb">
            <a href="{{route('admin.index')}}">
                <div class="text-tiny">Dashboard|</div>
            </a>
            <li>
                <a href="#">
                <div class="text-tiny">All Messages</div>
            </li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body mt-3">
              <!-- Table with stripped rows -->
              <div class="table-responsive mt-3">
              <table class="table table-striped table-bordered mt-3 table-responsive">
                @if(Session::has('status'))
                <p class="alert alert-success">{{Session::get('status')}}</p>
                @endif
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Comment</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($contacts as $contact)
                    <tr>
                        <td>{{ $contact->id }}</td>
                        <td>{{ $contact->name}}</td>
                        <td>{{ $contact->phone }}</td>
                        <td>{{ $contact->email }}</td>
                        <td>{{ $contact->comment}}</td>
                        <td>{{ $contact->created_at}}</td>
                        <td>
                            <div class="row">
                             <div class="col-6">
                                <a href="{{ route('admin.contact.delete',['id'=>$contact->id])}}">
                                    <div class="item text-danger delete">
                                        <i class="bi bi-trash">delete</i>
                                    </div>
                                </a>
                            </div>
                            </div>

                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
              </div>
              <!-- End Table with stripped rows -->
              <div class="divider"></div>
              <div class="flex items-center justify-between flex-wrap gap10 wgp-pagination">
               {{$contacts->links('pagination::bootstrap-5')}}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    </div>
  @endsection


  @push('scripts')
  <script>
      $(function(){
          $('.delete').on('click',function(e){
              e.preventDefault();
              var form=$(this).closest('form');
              swal({
                  title:"Are you sure?",
                  text:"you want to delete this record?",
                  type:"warning",
                  buttons:["No","Yes"],
                  confirmButtonColor:'#dc3545'
              }).then(function(result){
                  if(result){
                      form.submit();
                  }
              });
          });
      })
  </script>
@endpush
