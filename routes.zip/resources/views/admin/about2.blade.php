@extends('layouts.admin')
@section('content')


<h1>About Page </h1>

<div class="main-content-inner">
    <div class="main-content-wrap">

        <!-- new-category -->
        <div class="wg-box">
            <form class="form-new-product form-style-1" action="{{ route('about_store') }}" method="POST"
                enctype="multipart/form-data">
                @csrf
                <fieldset>
                    <div class="body-title">Drop Your Picture Here <span class="tf-color-1">*</span></div>
                    <input class="flex-grow" type="file" placeholder="Our Story" name="pic" value="{{ old('pic') }}" tabindex="0" value="" aria-required="true" required="">
                </fieldset>
                @error('pic')
                <span class="alert alert-danger text-center">{{ $message }}</span>
            @enderror





                <fieldset class="name">
                    <div class="body-title">Our Story <span class="tf-color-1">*</span></div>
                    <input class="flex-grow" type="text" placeholder="Our Story" name="story" value="{{ old('story') }}" tabindex="0" value="" aria-required="true" required="">
                </fieldset>

                @error('story')
                    <span class="alert alert-danger text-center">{{ $message }}</span>
                @enderror


                <fieldset class="name">
                    <div class="body-title">Our Mission<span class="tf-color-1">*</span></div>
                    <input class="flex-grow" type="text" placeholder="Our Mission" name="mission" value="{{ old('mission') }}" tabindex="0" value="" aria-required="true" required="">
                </fieldset>

                @error('mission')
                    <span class="alert alert-danger text-center">{{ $message }}</span>
                @enderror


                <fieldset class="name">
                    <div class="body-title">Our Vision<span class="tf-color-1">*</span></div>
                    <input class="flex-grow" type="text" placeholder="Our Vision" name="vision" value="{{ old('vision') }}" tabindex="0" value="" aria-required="true" required="">
                </fieldset>

                @error('vision')
                    <span class="alert alert-danger text-center">{{ $message }}</span>
                @enderror


                <fieldset class="name">
                    <div class="body-title">The Company<span class="tf-color-1">*</span></div>
                    <input class="flex-grow" type="text" placeholder="The Company" name="company" value="{{ old('company') }}" tabindex="0" value="" aria-required="true" required="">
                </fieldset>

                @error('company')
                    <span class="alert alert-danger text-center">{{ $message }}</span>
                @enderror



                <div class="bot">
                    <div></div>
                    <button class="tf-button w208" type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
