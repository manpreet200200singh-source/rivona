
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin | YourStore</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --success: #2ecc71;
            --error: #e74c3c;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .header h1 {
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .header p {
            color: #777;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark);
        }

        input, textarea, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border 0.3s;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--secondary);
        }

        textarea {
            resize: vertical;
            min-height: 120px;
        }

        .file-input {
            position: relative;
            overflow: hidden;
        }

        .file-input input[type="file"] {
            position: absolute;
            font-size: 100px;
            opacity: 0;
            right: 0;
            top: 0;
        }

        .file-input-label {
            display: flex;
            align-items: center;
            padding: 12px;
            background: var(--light);
            border: 1px dashed #ddd;
            border-radius: 4px;
            cursor: pointer;
        }

        .file-input-label i {
            margin-right: 10px;
            color: var(--secondary);
        }

        .btn {
            display: inline-block;
            background: var(--secondary);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: background 0.3s;
            width: 100%;
        }

        .btn:hover {
            background: var(--primary);
        }

        .captcha-container {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1.5rem;
        }

        .captcha-container input {
            flex: 1;
        }

        .captcha-code {
            font-family: 'Courier New', monospace;
            background: var(--light);
            padding: 8px 12px;
            border-radius: 4px;
            letter-spacing: 3px;
            user-select: none;
        }

        .footer-note {
            margin-top: 1.5rem;
            text-align: center;
            font-size: 14px;
            color: #777;
        }

        @media (max-width: 768px) {
            .container {
                margin: 1rem;
                padding: 1.5rem;
            }
        }

        /* Validation styles */
        .error-message {
            color: var(--error);
            font-size: 14px;
            margin-top: 5px;
        }

        .success-message {
            color: var(--success);
            text-align: center;
            margin-bottom: 1.5rem;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
               <a type="submit" class="btn" href="{{ route('home.index') }}">
                <i class="fas fa-paper-plane"></i> Shop Now!
            </a>
            <h1>Contact Store Admin</h1>
            <p>Have questions or need assistance? Fill out the form below and we'll get back to you shortly.</p>
        </div>

        <div class="success-message" id="successMessage">
            <p>Your message has been sent successfully! We'll respond within 24 hours.</p>
        </div>

        <form  action="{{ route('inquirystore') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label >Full Name</label>
                <input type="text"  name="fullname" placeholder="Enter your full name" required>

            </div>

            <div class="form-group">
                <label >Email Address</label>
                <input type="email"  name="email" placeholder="Enter your email address" required>

            </div>

            <div class="form-group">
                <label >Phone Number</label>
                <input type="tel" name="number" placeholder="Enter your phone number">

            </div>

            <div class="form-group">
                <label >Order Number</label>
                <input type="text"  name="ordernumber" placeholder="Enter your order number">
            </div>

            <div class="form-group">
                <label >Inquiry Type</label>
                <select  name="inquiry" required>
                    <option value="" disabled selected>Select inquiry type</option>
                    <option value="order-status">Order Status</option>
                    <option value="product-inquiry">Product Inquiry</option>
                    <option value="payment-issue">Payment Issue</option>
                    <option value="return-exchange">Return/Exchange</option>
                    <option value="technical-support">Technical Support</option>
                    <option value="general">General Question</option>
                </select>
            </div>

            <div class="form-group">
                <label>Subject</label>
                <input type="text"  name="subject" placeholder="Briefly describe your inquiry" required>

            </div>

            <div class="form-group">
                <label >Message</label>
                <textarea  name="message" placeholder="Please provide details about your inquiry..." required></textarea>

            </div>

            <div class="form-group">
                <label class="file-input-label">
                    <i class="fas fa-paperclip"></i>
                    <span>Attach Files</span>
                </label>
                <input type="file"  name="file" class="file-input">
            </div>




            <button type="submit" class="btn">
                <i class="fas fa-paper-plane"></i> Submit Message
            </button>
        </form>

        <div class="footer-note">
            <p>We typically respond within 24 hours during business days.</p>
        </div>
    </div>


</body>
</html>

