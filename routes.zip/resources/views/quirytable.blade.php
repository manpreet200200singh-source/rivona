
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inquiries List</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6 bg-blue-600 text-white">
                <h1 class="text-2xl font-bold">Inquiries Management</h1>
                <p class="opacity-75">List of all inquiries</p>
            </div>

            <div class="p-6">
                <div class="mb-6 flex justify-between items-center">
                    <div class="relative w-64">
                        <input type="text" id="search" placeholder="Search inquiries..."
                               class="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                    </div>
                    <a class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition" href="{{route('admin.index') }}">
                         back
                    </a>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider cursor-pointer hover:text-blue-600 sortable" data-column="id">
                                    ID
                                </th>
                                <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider cursor-pointer hover:text-blue-600 sortable" data-column="fullname">
                                    Full Name
                                </th>
                                <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider cursor-pointer hover:text-blue-600 sortable" data-column="email">
                                    Email
                                </th>
                                   <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Mobile Number
                                </th>

                                <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Order Number
                                </th>
                                  <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Inquiry Number
                                </th>
                                  <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Subject
                                </th>
                                   <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Message
                                   </th>
                                     <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    File
                                   </th>

                                <th class="px-6 py-3 text-left text-xs  text-gray-500 uppercase tracking-wider">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach($quiries as $quiry)
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->id }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->fullname }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <a href="mailto:{{ $quiry->email }}" class="text-blue-600 hover:underline">{{ $quiry->email }}</a>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->number }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->ordernumber }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->inquiry }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->subject }}</td>
                                <td class="px-6 py-4 whitespace-nowrap">{{ $quiry->message }}</td>
                                <td class="px-6 py-4 whitespace-nowrap"><img src="{{ asset('public/uploads/inquiry/'.$quiry->file) }}" alt=""></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm ">
                                    {{-- <button class="text-blue-600 hover:text-blue-800 mr-3 view-btn" data-id="{{ $quiry->id }}">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="text-green-600 hover:text-green-800 mr-3 edit-btn" data-id="{{ $quiry->id }}">
                                        <i class="fas fa-edit"></i>
                                    </button> --}}
                                    <a class="text-red-600 hover:text-red-800 delete-btn" href="{{ route('inquirydelete',$quiry->id) }}">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="mt-4 flex items-center justify-between">
                    <div class="text-sm text-gray-700">
                        Showing <span class="">{{ $quiries->firstItem() }}</span>
                        to <span class="">{{ $quiries->lastItem() }}</span>
                        of <span class="">{{ $quiries->total() }}</span> entries
                    </div>
                    <div class="flex">
                        {{ $quiries->links() }} <!-- This will render pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Modal -->

    <script>
        // View functionality
        document.querySelectorAll('.view-btn').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                fetch(`/inquiries/${id}`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('view-id').textContent = data.id;
                        document.getElementById('view-fullname').textContent = data.fullname;
                        document.getElementById('view-email').textContent = data.email;
                        document.getElementById('view-number').textContent = data.number;
                        document.getElementById('view-ordernumber').textContent = data.ordernumber;
                        document.getElementById('view-subject').textContent = data.subject;
                        document.getElementById('view-message').textContent = data.message;

                        if(data.file) {
                            document.getElementById('view-file').style.display = 'inline-block';
                            document.getElementById('view-file').href = `/storage/${data.file}`;
                        } else {
                            document.getElementById('view-file').style.display = 'none';
                        }

                        document.getElementById('viewModal').classList.remove('hidden');
                    });
            });
        });

        document.getElementById('closeViewModal').addEventListener('click', function() {
            document.getElementById('viewModal').classList.add('hidden');
        });

        // Search functionality
        document.getElementById('search').addEventListener('input', function() {
            const searchValue = this.value.toLowerCase();
            document.querySelectorAll('tbody tr').forEach(row => {
                const text = row.textContent.toLowerCase();
                if(text.includes(searchValue)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Sort functionality
        document.querySelectorAll('.sortable').forEach(header => {
            header.addEventListener('click', function() {
                const column = this.getAttribute('data-column');
                const currentUrl = new URL(window.location.href);

                // Toggle between asc and desc
                if(currentUrl.searchParams.get('sort') === column) {
                    currentUrl.searchParams.set('direction',
                        currentUrl.searchParams.get('direction') === 'asc' ? 'desc' : 'asc');
                } else {
                    currentUrl.searchParams.set('sort', column);
                    currentUrl.searchParams.set('direction', 'asc');
                }

                window.location.href = currentUrl.toString();
            });
        });
    </script>
</body>
</html>
