@extends('layouts.app')
@section('content')
    <style>
        .filled-heart {
            color:  #e67e22;
        }
        .review-star.filled {
            fill: #e67e22;
        }
    </style>
    <main class="pt-90">
        <div class="mb-md-1 pb-md-3"></div>
        <section class="product-single container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="product-single__media" data-media-type="vertical-thumbnail">
                        <div class="product-single__image">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">

                                    <div class="swiper-slide product-single__image-item">
                                        <img loading="lazy" class="h-auto"
                                            src="{{ asset('uploads/products') }}/{{ $product->image }}" width="450px"
                                            height="450px" alt="" />
                                        <a data-fancybox="gallery"
                                            href="{{ asset('uploads/products') }}/{{ $product->image }}"
                                            data-bs-toggle="tooltip" data-bs-placement="left" title="Zoom">
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <use href="#icon_zoom" />
                                            </svg>
                                        </a>
                                    </div>
                                    @foreach (explode(',', $product->images) as $gimg)
                                        <div class="swiper-slide product-single__image-item">
                                            <img loading="lazy" class="h-auto"
                                                src="{{ asset('uploads/products') }}/{{ $gimg }}" width="450px"
                                                height="450px" alt="" />
                                            <a data-fancybox="gallery"
                                                href="{{ asset('uploads/products') }}/{{ $gimg }}"
                                                data-bs-toggle="tooltip" data-bs-placement="left" title="Zoom">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <use href="#icon_zoom" />
                                                </svg>
                                            </a>
                                        </div>
                                    @endforeach


                                </div>
                                <div class="swiper-button-prev"><svg width="7" height="11" viewBox="0 0 7 11"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <use href="#icon_prev_sm" />
                                    </svg></div>
                                <div class="swiper-button-next"><svg width="7" height="11" viewBox="0 0 7 11"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <use href="#icon_next_sm" />
                                    </svg></div>
                            </div>
                        </div>
                        <div class="product-single__thumbnail">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide product-single__image-item">
                                        <img loading="lazy" class="h-auto"
                                            src="{{ asset('uploads/products/thumbnails') }}/{{ $product->image }}"
                                            width="104" height="104" alt="" />
                                    </div>
                                    @foreach (explode(',', $product->images) as $gimg)
                                        <div class="swiper-slide product-single__image-item"><img loading="lazy"
                                                class="h-auto"src="{{ asset('uploads/products/thumbnails/') }}/{{ $gimg }}"
                                                width="104" height="104" alt="" /></div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="d-flex justify-content-between mb-4 pb-md-2">
                        <div class="breadcrumb mb-0 d-none d-md-block flex-grow-1">
                            <a href="{{ route('home.index') }}"
                                class="menu-link menu-link_us-s text-uppercase fw-medium">Home</a>
                            <span class="breadcrumb-separator menu-link fw-medium ps-1 pe-1">/</span>
                            <a href="#" class="menu-link menu-link_us-s text-uppercase fw-medium">The Shop</a>
                        </div><!-- /.breadcrumb -->

                        <div
                            class="product-single__prev-next d-flex align-items-center justify-content-between justify-content-md-end flex-grow-1">
                            <a href="{{ route('home.index') }}" class="text-uppercase fw-medium"><svg width="10"
                                    height="10" viewBox="0 0 25 25" xmlns="http://www.w3.org/2000/svg">
                                    <use href="#icon_prev_md" />
                                </svg><span class="menu-link menu-link_us-s">Prev</span></a>
                            <a href="{{ route('shop.index') }}" class="text-uppercase fw-medium"><span
                                    class="menu-link menu-link_us-s">Next</span><svg width="10" height="10"
                                    viewBox="0 0 25 25" xmlns="http://www.w3.org/2000/svg">
                                    <use href="#icon_next_md" />
                                </svg></a>
                        </div><!-- /.shop-acs -->
                    </div>
                    <h1 class="product-single__name">{{ $product->name }}</h1>
                      <span class="average-rating__note text-secondary">

                                    </span>
                    <div class="product-single__rating">
                     <div class="reviews-group d-flex">
                       <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                         <use href="#icon_star" />
                       </svg>
                       <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                         <use href="#icon_star" />
                       </svg>
                       <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                         <use href="#icon_star" />
                       </svg>
                       <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                         <use href="#icon_star" />
                       </svg>
                       <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                         <use href="#icon_star" />
                       </svg>
                     </div>
                     <span class="reviews-note text-lowercase text-secondary ms-1">  {{ $rating->where('product_id', $product->id)->count() }} global ratings</span>
                   </div>
                    <div class="product-single__price">
                        <span class="current-price">
                            @if ($product->sale_price)
                                <s>{{ $product->regular_price }}</s>£{{ $product->sale_price }}
                            @else
                                £{{ $product->regular_price }}
                            @endif
                        </span>
                    </div>
                    <div class="product-single__price">
                        <span class="current-price">
                            Released:3rd march
                            {{ $product->released_date }}
                        </span>
                    </div>
                    <div class="product-single__short-desc">
                        @php
                            $shortDesc = Str::limit($product->short_description, 120, '...');
                            $fullDesc = $product->short_description;
                        @endphp
                        {{-- thek eh hmm hor kush payment ? chalo pher live stock vi karna c asha details  --}}
                        <p id="short-desc">
                            {{ $shortDesc }}
                            @if (strlen($fullDesc) > 120)
                                <a href="javascript:void(0);" id="toggle-desc"
                                    style="color:brown; font-weight: bold">Show more</a>
                            @endif
                        </p>
                        <p id="full-desc" style="display:none;">
                            {{ $fullDesc }}
                            <a href="javascript:void(0);" id="toggle-less" style="color:brown; font-weight: bold">Show
                                less</a>
                        </p>

                        @push('scripts')
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    var toggleDesc = document.getElementById('toggle-desc');
                                    var toggleLess = document.getElementById('toggle-less');
                                    var shortDesc = document.getElementById('short-desc');
                                    var fullDesc = document.getElementById('full-desc');

                                    if (toggleDesc) {
                                        toggleDesc.addEventListener('click', function() {
                                            shortDesc.style.display = 'none';
                                            fullDesc.style.display = 'block';
                                        });
                                    }
                                    if (toggleLess) {
                                        toggleLess.addEventListener('click', function() {
                                            fullDesc.style.display = 'none';
                                            shortDesc.style.display = 'block';
                                        });
                                    }
                                });
                            </script>
                        @endpush
                    </div>
                    @if (Cart::instance('cart')->content()->where('id', $product->id)->count() > 0)
                        <a href="{{ route('cart.index') }}" class=" btn btn-warning mb-3">Go to cart</a>
                    @else
                        <form name="addtocart-form" method="post" action="{{ route('cart.add') }}">
                            @csrf
                            <div class="product-single__addtocart">
                                <div class="qty-control position-relative">
                                    <input type="number" name="quantity" value="1" min="1"
                                        class="qty-control__number text-center">
                                    <div class="qty-control__reduce">-</div>
                                    <div class="qty-control__increase">+</div>
                                </div><!-- .qty-control -->
                                <input type="hidden" name="id" value="{{ $product->id }}" />
                                <input type="hidden" name="name" value="{{ $product->name }}" />
                                <input type="hidden" name="price"
                                    value="{{ $product->sale_price == '' ? $product->regular_price : $product->sale_price }}">

                                @if ($product->quantity > 0)
                                    <button type="submit" class="btn btn-primary  "
                                        data-aside="cartDrawer">Add to Cart</button>
                                @else
                                    <button class=" btn btn-outline-light btn-addtocart" type="button" style="color: red;" data-aside="">Out of
                                        Stock</button>

                                @endif

                            </div>
                        </form>
                    @endif
                {{-- kadd ke dwa jithe code aa ?  --}}
                    <div class="product-single__addtolinks">

                        @if (Cart::instance('wishlist')->content()->where('id', $product->id)->count() > 0)
                            <a href="javascript:void(0)" class="menu-link menu-link_us-s add-to-wishlist filled-heart"
                                onclick="document.getElementById('frm-remove-item').submit();"><svg width="16"
                                    height="16" viewBox="0 0 20 20" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <use href="#icon_heart" />
                                </svg><span>Remove from Wishlist</span>
                            </a>
                        @else
                            <form action="{{ route('wishlist.add') }}" method="POST" id="wishlist-form">
                                @csrf
                                <input type="hidden" name="id" value="{{ $product->id }}">
                                <input type="hidden" name="name" value="{{ $product->name }}">
                                <input type="hidden" name="price"
                                    value="{{ $product->sale_price == '' ? $product->regular_price : $product->sale_price }}">
                                <input type="hidden" name="quantity" value="1">
                                <a href="javascript:void(0)" class="menu-link menu-link_us-s add-to-wishlist"
                                    onclick="document.getElementById('wishlist-form').submit();"><svg width="16"
                                        height="16" viewBox="0 0 20 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <use href="#icon_heart" />
                                    </svg><span>Add to Wishlist</span>
                                </a>
                            </form>
                        @endif

                        <share-button class="share-button">
                            {{-- <button class="menu-link menu-link_us-s to-share border-0 bg-transparent d-flex align-items-center">
                <svg width="16" height="19" viewBox="0 0 16 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <use href="#icon_sharing" />
                </svg>
                <span>Share</span>
              </button> --}}
                            <details id="Details-share-template__main" class="m-1 xl:m-1.5" hidden="">
                                <summary class="btn-solid m-1 xl:m-1.5 pt-3.5 pb-3 px-5">+</summary>
                                <div id="Article-share-template__main"
                                    class="share-button__fallback flex items-center absolute top-full left-0 w-full px-2 py-4 bg-container shadow-theme border-t z-10">
                                    <div class="field grow mr-4">
                                        <label class="field__label sr-only" for="url">Link</label>
                                        <input type="text" class="field__input w-full" id="url"
                                            value="https://uomo-crystal.myshopify.com/blogs/news/go-to-wellness-tips-for-mental-health"
                                            placeholder="Link" onclick="this.select();" readonly="">
                                    </div>
                                    <button class="share-button__copy no-js-hidden">
                                        <svg class="icon icon-clipboard inline-block mr-1" width="11" height="13"
                                            fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"
                                            focusable="false" viewBox="0 0 11 13">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M2 1a1 1 0 011-1h7a1 1 0 011 1v9a1 1 0 01-1 1V1H2zM1 2a1 1 0 00-1 1v9a1 1 0 001 1h7a1 1 0 001-1V3a1 1 0 00-1-1H1zm0 10V3h7v9H1z"
                                                fill="currentColor"></path>
                                        </svg>
                                        <span class="sr-only">Copy link</span>
                                    </button>
                                </div>
                            </details>
                        </share-button>
                        <script src="js/details-disclosure.html" defer="defer"></script>
                        <script src="js/share.html" defer="defer"></script>
                    </div>
                    <div class="product-single__meta-info">
                        <div class="meta-item">
                            <label>Format:</label>
                            <span>{{ $product->SKU }}</span>
                        </div>
                        <div class="meta-item">
                            <label>Categories:</label>
                            <span>{{ $product->category->name }}</span>
                        </div>
                        <div class="meta-item">
                            <label>Barcode:</label>
                            <!--<img src="{{ asset('barcodes/') }}/{{ $product->barcode_img }}" alt="Barcode" class="img-fluid" style="max-width:150px;">-->
                            {{-- <img src="{{ asset(''.$product->barcode_img) }}" alt="Barcode" class="img-fluid" style="max-width:150px; height:50px;"><br> --}}
                            <span style="margin-left:10px;"> {{ $product->barcode }}<span>
                        </div>

                        <br><br>
                        <div class="tab-pane" role="tabpanel" aria-labelledby="tab-reviews-tab">
                            <div class="product-single__addtional-info">
                                <div class="item">
                                    <h4 class="h6">Delivery</h4>
                                    <span>*Free UK delivery on orders over £20
                                        (exclusions apply)
                                        Usually dispatched within 24 hours </span>
                                </div>
                                <div class="item">
                                    <h4 class="h6">Click & Collect (UK only)</h4>
                                    <span>Get it delivered to a UK store near you with FREE Click & Collect available on
                                        this product.</span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {{-- ////next --}}
            <div class="product-single__details-tab">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link nav-link_underscore active" id="tab-description-tab" data-bs-toggle="tab"
                            href="#tab-description" role="tab" aria-controls="tab-description"
                            aria-selected="true">Description</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link nav-link_underscore" id="tab-additional-info-tab" data-bs-toggle="tab"
                            href="#tab-additional-info" role="tab" aria-controls="tab-additional-info"
                            aria-selected="false">Additional Information</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link nav-link_underscore" id="tab-reviews-tab" data-bs-toggle="tab"
                            href="#tab-reviews" role="tab" aria-controls="tab-reviews"
                            aria-selected="false">REVIEWS</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tab-description" name="tab-description-tab"
                        role="tabpanel" aria-labelledby="tab-description-tab">
                        <div class="product-single__description">
                            <h3 class="block-title mb-4">{{ $product->description }}</p>
                                {{-- <div class="row">
                <div class="col-lg-6">
                  <h3 class="block-title">Why choose product?</h3>
                  <ul class="list text-list">
                    <li>Creat by cotton fibric with soft and smooth</li>
                    <li>Simple, Configurable (e.g. size, color, etc.), bundled</li>
                    <li>Downloadable/Digital Products, Virtual Products</li>
                  </ul>
                </div>
                <div class="col-lg-6">
                  <h3 class="block-title">Sample Number List</h3>
                  <ol class="list text-list">
                    <li>Create Store-specific attrittbutes on the fly</li>
                    <li>Simple, Configurable (e.g. size, color, etc.), bundled</li>
                    <li>Downloadable/Digital Products, Virtual Products</li>
                  </ol>
                </div>
              </div>
           <h3 class="block-title mb-0">Lining</h3>
              <p class="content">100% Polyester, Main: 100% Polyester.</p> --}}
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab-additional-info" role="tabpanel"
                        aria-labelledby="tab-additional-info-tab">
                        <div class="product-single__addtional-info">
                            <div class="item">
                                <label class="h6">Region Code</label>
                                <span>Region
                                    {{ $product->region_code }}
                                </span>
                            </div>
                            <div class="item">
                                <label class="h6">Format</label>
                                <span>{{ $product->SKU }}</span>
                            </div>
                            <div class="item">
                                <label class="h6">Duration</label>
                                <span>
                                    {{ $product->duration }}
                                </span>

                            </div>
                            <div class="item">
                                <label class="h6">Language</label>
                                <span><b>Language(s)</b>:
                                    {{ $product->language }}
                                </span>
                            </div>
                        </div>
                    </div>
                    {{-- <div class="tab-pane fade" id="tab-reviews" role="tabpanel" aria-labelledby="tab-reviews-tab">
            <div class="product-single__addtional-info">
              <div class="item">
                <label class="h6">International Delivery:</label>
                <p>International delivery costs will be calculated within the basket according to the size and weight of the parcel required. Find out more here. </p>
                <ul>
                    <li>Delivery costs are calculated based on the weight and size of your order, as well as the destination country.</li>
                    <li>Customs duties and taxes may apply for international orders, which are the responsibility of the recipient.</li>
                    <li>Delivery times may vary depending on the destination country and customs processing times.</li>
                    <li>We recommend checking with your local customs office for any specific regulations or requirements.</li>
                </ul>
              </div>
              <div class="item">
                <label class="h6">When will my order arrive? </label>
                <p>
                    All orders are processed within 1-2 business days. Delivery times may vary depending on your location and the shipping method selected at checkout. You will receive a tracking number once your order has shipped.
                </p>
              </div>
                    <div class="item">
                <label class="h6">Will you tell me when my order is on its way? </label>
                <p>
                    Yes, you will receive an email confirmation with a tracking number once your order has shipped.

                </p>
              </div>
               <div class="item">
                <label class="h6">Trusted Suppliers</label>
                <p>Products labelled '*item fulfilled by Exertis on behalf of hmv' will be supplied to you directly by Exertis via their approved couriers. When you place an order for an item that is fulfilled by Exertis, your details shall be forwarded to them so that they can fulfil the order, and to their courier so that they can deliver the item.

                </p>
              </div>
                <div class="item">
                <label class="h6">Returns</label>
                <p>If you are not completely satisfied with your purchase, you may return it within 14 days of receipt for a full refund or exchange. Please ensure that the item is in its original condition and packaging. To initiate a return, please contact our customer service team for assistance.
                </p>
              </div>

            </div>
          </div> --}}
                    {{-- write the code how many views and if one star is give then how many users give rating 1 and if two star is give then how many users give rating 2 if three star is give then how many users give rating 3 if four star is give then how many users give rating 4 if five star is give then how many users give rating 5 --}}



                   <div class="tab-pane fade" id="tab-reviews" role="tabpanel" aria-labelledby="tab-reviews-tab">
    <h2 class="product-single__reviews-title">Reviews</h2>

    <div class="product-single__reviews">
        <div class="reviews-group d-flex align-items-center mb-3">
            <div class="average-rating me-4">
                <span class="average-rating__number">{{ number_format($rating->avg('stars'), 1) }}</span>
                <div class="average-rating__stars">
                    @for ($i = 1; $i <= 5; $i++)
                        @if ($i <= floor($rating->avg('stars')))
                            <svg class="review-star filled" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                                <use href="#icon_star" />
                            </svg>
                        @else
                            <svg class="review-star" viewBox="0 0 9 9" xmlns="http://www.w3.org/2000/svg">
                                <use href="#icon_star" />
                            </svg>
                        @endif
                    @endfor
                </div>
                <span class="average-rating__note text-secondary">
                    {{ $rating->where('product_id', $product->id)->count() }}
                    global ratings
                </span>
            </div>
        </div>

        {{-- Amazon-style rating breakdown --}}
        <button class="btn btn-dark" type="button" id="show-rating-table-btn" style="font-size: 1.1rem;">CLICK TO VIEW RATING</button>
        <table class="table table-bordered mt-3" style="display:none;" id="rating-table">
            <thead>
                <tr>
                    <th>Star</th>
                    <th>Percentage</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                @for ($star = 5; $star >= 1; $star--)
                    @php
                        $count = $rating->where('stars', $star)->count();
                        $percentage = $rating->count() > 0 ? ($count / $rating->count()) * 100 : 0;
                    @endphp
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="me-2" style="width:40px;">{{ $star }} star</span>
                                <div class="progress flex-grow-1" style="height:10px; min-width:100px;">
                                    <div class="progress-bar bg-danger" role="progressbar"
                                        style="width: {{ $percentage }}%"
                                        aria-valuenow="{{ round($percentage) }}" aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>{{ round($percentage) }}%</td>
                        <td>{{ $count }}</td>
                    </tr>
                @endfor
            </tbody>
        </table>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('show-rating-table-btn').addEventListener('click', function() {
                    var table = document.getElementById('rating-table');
                    if (table.style.display === 'none' || table.style.display === '') {
                        table.style.display = 'table';
                    } else {
                        table.style.display = 'none';
                    }
                });
            });
        </script>

        <div class="rating-section my-5">
            <div class="card shadow-sm border-0 mx-auto" style="max-width: 420px; border-radius: 14px;">
                <div class="card-body p-4">
                    <h4 class="mb-3 fw-semibold text-center" style="letter-spacing: 0.5px;">
                        Rate <span style="color: #e67e22;">{{ $product->name }}</span>
                    </h4>
                    <form id="ratingForm" method="POST" action="{{ route('rate.store') }}">
                        @csrf
                        <div class="mb-3 text-center">
                            <label for="starsInput" class="form-label mb-2" style="font-size: 1rem; color: #555;">Your Rating</label>
                            <div id="stars" class="d-inline-block">
                                <span class="star" data-value="1">&#9733;</span>
                                <span class="star" data-value="2">&#9733;</span>
                                <span class="star" data-value="3">&#9733;</span>
                                <span class="star" data-value="4">&#9733;</span>
                                <span class="star" data-value="5">&#9733;</span>
                            </div>
                            <input type="hidden" id="starsInput" name="stars" value="0">
                            @error('stars')
                                <div class="alert alert-danger py-1 px-2 mt-2">{{ $message }}</div>
                            @enderror
                        </div>
                        <input type="hidden" name="product_id" value="{{ $product->id }}">
                        @error('product_id')
                            <div class="alert alert-danger py-1 px-2 mt-2">{{ $message }}</div>
                        @enderror
                        <div class="mb-3">
                            <input type="text" name="name" placeholder="Your Name" required class="form-control form-control-lg rounded-3 shadow-none">
                            @error('name')
                                <div class="alert alert-danger py-1 px-2 mt-2">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <input type="email" name="email" placeholder="Your Email" required class="form-control form-control-lg rounded-3 shadow-none">
                            @error('email')
                                <div class="alert alert-danger py-1 px-2 mt-2">{{ $message }}</div>
                            @enderror
                        </div>
                        <button type="submit" class="btn btn-dark w-100 fw-bold py-2" style="font-size: 1.1rem;">Submit Rating</button>
                    </form>
                    <div id="message" class="mt-3 text-center"></div>
                </div>
            </div>
        </div>
        <style>
            /* Styles as before, with minor additions */
            .rating-section .star {
                font-size: 2.2rem;
                color: #e0e0e0;
                cursor: pointer;
                transition: color 0.2s, transform 0.1s;
                margin-right: 4px;
                display: inline-block;
                vertical-align: middle;
            }
            .rating-section .star.filled {
                color: #e67e22;
                text-shadow: 0 2px 8px rgba(230, 126, 34, 0.15);
                transform: scale(1.08);
            }
            /* ... rest of your styles ... */
        </style>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(function() {
                let selectedStars = 0;

                $('.star').on('mouseenter', function() {
                    let val = $(this).data('value');
                    highlightStars(val);
                });

                $('.star').on('mouseleave', function() {
                    highlightStars(selectedStars);
                });

                $('.star').on('click', function() {
                    selectedStars = $(this).data('value');
                    $('#starsInput').val(selectedStars);
                    highlightStars(selectedStars);
                });

                function highlightStars(count) {
                    $('.star').each(function() {
                        let starVal = $(this).data('value');
                        if (starVal <= count) {
                            $(this).addClass('filled');
                        } else {
                            $(this).removeClass('filled');
                        }
                    });
                }

                $('#ratingForm').on('submit', function(e) {
                    e.preventDefault();

                    if (selectedStars === 0) {
                        $('#message').html('<div class="alert alert-danger py-1 px-2">Please select a star rating.</div>');
                        return;
                    }

                    $.ajax({
                        url: "{{ route('rate.store') }}",
                        method: 'POST',
                        data: $(this).serialize(),
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(response) {
                            $('#message').html('<div class="alert alert-success py-1 px-2">' + response.message + '</div>');
                            $('#ratingForm')[0].reset();
                            selectedStars = 0;
                            highlightStars(0);
                        },
                        error: function(xhr) {
                            let errors = xhr.responseJSON.errors || { general: ['An error occurred'] };
                            let errorMessages = [];
                            for (let key in errors) {
                                errorMessages.push(errors[key][0]);
                            }
                            $('#message').html('<div class="alert alert-danger py-1 px-2">' + errorMessages.join('<br>') + '</div>');
                        }
                    });
                });
            });
        </script>
    </div>
</div>

        </section>

        <section class="products-carousel container">
            <h2 class="h3 text-uppercase mb-4 pb-xl-2 mb-xl-4">Related <strong>Products</strong></h2>

            <div id="related_products" class="position-relative">
                <div class="swiper-container js-swiper-slider"
                    data-settings='{
            "autoplay": false,
            "slidesPerView": 4,
            "slidesPerGroup": 4,
            "effect": "none",
            "loop": true,
            "pagination": {
              "el": "#related_products .products-pagination",
              "type": "bullets",
              "clickable": true
            },
            "navigation": {
              "nextEl": "#related_products .products-carousel__next",
              "prevEl": "#related_products .products-carousel__prev"
            },
            "breakpoints": {
              "320": {
                "slidesPerView": 2,
                "slidesPerGroup": 2,
                "spaceBetween": 14
              },
              "768": {
                "slidesPerView": 3,
                "slidesPerGroup": 3,
                "spaceBetween": 24
              },
              "992": {
                "slidesPerView": 4,
                "slidesPerGroup": 4,
                "spaceBetween": 30
              }
            }
          }'>

                    <div class="swiper-wrapper">



                        @foreach ($rproducts as $rproduct)
                            <div class="swiper-slide product-card">
                                <div class="pc__img-wrapper">
                                    <a href="{{ route('shop.product.details', ['product_slug' => $rproduct->slug]) }}">
                                        <img loading="lazy" src="{{ asset('uploads/products') }}/{{ $rproduct->image }}"
                                            width="330" height="400"alt="{{ $rproduct->name }}" class="pc__img">
                                        @foreach (explode(',', $rproduct->images) as $gimg)
                                            <img loading="lazy"
                                                src="{{ asset('uploads/products') }}/{{ $gimg }}" width="330"
                                                height="400"alt="{{ $rproduct->name }}" class="pc__img pc__img-second">
                                        @endforeach
                                    </a>
                                    @if (Cart::instance('cart')->content()->where('id', $product->id)->count() > 0)
                                        <a href="{{ route('cart.index') }}" class=" btn btn-warning mb-3">Go to cart</a>
                                    @else
                                        <form name="addtocart-form" method="post" action="{{ route('cart.add') }}">
                                            @csrf
                                            <div class="product-single__addtocart">
                                                <div class="qty-control position-relative">
                                                    <input type="number" name="quantity" value="1" min="1"
                                                        class="qty-control__number text-center">
                                                    <div class="qty-control__reduce">-</div>
                                                    <div class="qty-control__increase">+</div>
                                                </div><!-- .qty-control -->
                                                <input type="hidden" name="id" value="{{ $product->id }}" />
                                                <input type="hidden" name="name" value="{{ $product->name }}" />
                                                <input type="hidden" name="price"
                                                    value="{{ $product->sale_price == '' ? $product->regular_price : $product->sale_price }}">
                                                <button type="submit" class="btn btn-primary btn-addtocart"
                                                    data-aside="cartDrawer">Add to Cart</button>
                                            </div>
                                        </form>
                                    @endif
                                </div>

                                <div class="pc__info position-relative">
                                    <p class="pc__category">{{ $rproduct->category->name }}</p>
                                    <h6 class="pc__title"><a
                                            href="{{ route('shop.product.details', ['product_slug' => $rproduct->slug]) }}">{{ $rproduct->name }}</a>
                                    </h6>
                                    <div class="product-card__price d-flex">
                                        <span class="money price">
                                            @if ($product->sale_price)
                                                <s>{{ $rproduct->regular_price }}</s>£{{ $rproduct->sale_price }}
                                            @else
                                                £{{ $product->regular_price }}
                                            @endif
                                        </span>
                                    </div>

                                    <button
                                        class="pc__btn-wl position-absolute top-0 end-0 bg-transparent border-0 js-add-wishlist"
                                        title="Add To Wishlist">
                                        <svg width="16" height="16" viewBox="0 0 20 20" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <use href="#icon_heart" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    <!-- /.swiper-wrapper -->
                </div><!-- /.swiper-container js-swiper-slider -->

                {{-- <div class="products-carousel__prev position-absolute top-50 d-flex align-items-center justify-content-center">
          <svg width="25" height="25" viewBox="0 0 25 25" xmlns="http://www.w3.org/2000/svg">
            <use href="#icon_prev_md" />
          </svg>
        </div><!-- /.products-carousel__prev -->
        <div class="products-carousel__next position-absolute top-50 d-flex align-items-center justify-content-center">
          <svg width="25" height="25" viewBox="0 0 25 25" xmlns="http://www.w3.org/2000/svg">
            <use href="#icon_next_md" />
          </svg>
        </div><!-- /.products-carousel__next --> --}}

                <div class="products-pagination mt-4 mb-5 d-flex align-items-center justify-content-center"></div>
                <!-- /.products-pagination -->
            </div><!-- /.position-relative -->

        </section><!-- /.products-carousel container -->
    </main>
@endsection
