<!DOCTYPE html>
<html>
<head>
    <title>Star Rating with AJAX</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        .star {
            font-size: 2rem;
            color: gray;
            cursor: pointer;
        }
        .star.filled {
            color: gold;
        }
    </style>
</head>
<body>

<h2>Rate Us</h2>

<form id="ratingForm">
    <div id="stars">
        <span class="star" data-value="1">&#9733;</span>
        <span class="star" data-value="2">&#9733;</span>
        <span class="star" data-value="3">&#9733;</span>
        <span class="star" data-value="4">&#9733;</span>
        <span class="star" data-value="5">&#9733;</span>
    </div>

    <input type="text" name="name" placeholder="Your Name" required><br><br>
    <input type="email" name="email" placeholder="Your Email" required><br><br>

    <input type="hidden" name="stars" id="starsInput" value="0">

    <button type="submit">Submit</button>
</form>

<div id="message"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    let selectedStars = 0;

    $('.star').on('mouseenter', function() {
        let val = $(this).data('value');
        highlightStars(val);
    });

    $('.star').on('mouseleave', function() {
        highlightStars(selectedStars);
    });

    $('.star').on('click', function() {
        selectedStars = $(this).data('value');
        $('#starsInput').val(selectedStars);
        highlightStars(selectedStars);
    });

    function highlightStars(count) {
        $('.star').each(function() {
            let starVal = $(this).data('value');
            if (starVal <= count) {
                $(this).addClass('filled');
            } else {
                $(this).removeClass('filled');
            }
        });
    }

    $('#ratingForm').on('submit', function(e) {
        e.preventDefault();

        if(selectedStars === 0) {
            alert('Please select a star rating.');
            return;
        }

        $.ajax({
            url: "{{ route('rate.store') }}",
            method: 'POST',
            data: $(this).serialize(),
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                $('#message').text(response.success).css('color', 'green');
                $('#ratingForm')[0].reset();
                selectedStars = 0;
                highlightStars(0);
            },
            error: function(xhr) {
                let errors = xhr.responseJSON.errors;
                let errorMessages = [];
                for(let key in errors) {
                    errorMessages.push(errors[key][0]);
                }
                $('#message').html(errorMessages.join('<br>')).css('color', 'red');
            }
        });
    });
});
</script>

</body>
</html>
